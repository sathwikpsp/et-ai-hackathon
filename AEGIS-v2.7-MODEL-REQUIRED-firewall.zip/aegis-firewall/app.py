"""Loopback-only security lab and JSON API. No uploaded code is executed."""
import json,time,os
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from collections import deque
from threading import Lock,BoundedSemaphore
from pif.pipeline import inspect
from pif.parsers import parse_html
from pif.guard import guard_tool
from pif.sessions import session_inspect,reset_session
from pif.uploads import extract_upload
from pif.lab import evaluate
from pif.agent import run_agent
from pif.llm import status as llm_status
ROOT=Path(__file__).parent
HISTORY=deque(maxlen=100); LOCK=Lock(); WORKERS=BoundedSemaphore(4)
SOURCES=('user','web','pdf','email','markdown','html','docx','api','ocr','code','image')

def record(v):
    with LOCK: HISTORY.appendleft({'action':v['action'],'risk':v['risk'],'source':v['source'],'latency_ms':v['latency_ms'],'time':time.strftime('%H:%M:%S'),'types':v['attack_types']})

class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup(); self.connection.settimeout(20)
    def reply(self,status,data,kind='application/json'):
        body=data.encode("utf-8") if isinstance(data,str) else json.dumps(data).encode()
        self.send_response(status); self.send_header('Content-Type',kind); self.send_header('Content-Length',str(len(body))); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Cache-Control','no-store'); self.send_header('Referrer-Policy','no-referrer'); self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"); self.end_headers(); self.wfile.write(body)
    def log_message(self,format,*args): pass  # Do not log submitted content.
    def do_GET(self):
        if self.path=='/': return self.reply(200,(ROOT/'demo/index.html').read_text(encoding='utf-8'),'text/html; charset=utf-8')
        if self.path=='/api/history':
            with LOCK: records=list(HISTORY)
            return self.reply(200,records)
        if self.path=='/api/health': return self.reply(200,{'status':'ok','model':'local character-ngram Naive Bayes','llm':llm_status(),'version':'2.7','semantic_judge_required':True,'privacy':'Semantic model adjudication is mandatory for live inspection. Cloud providers process content externally; Ollama stays local. If the selected model is unavailable, content is quarantined.'})
        self.reply(404,{'error':'Not found'})
    def do_POST(self):
        # Block cross-site requests against the unauthenticated loopback service.
        origin=self.headers.get('Origin')
        if origin and origin not in ('http://127.0.0.1:8765','http://localhost:8765'): return self.reply(403,{'error':'Cross-origin requests denied'})
        if not WORKERS.acquire(blocking=False): return self.reply(429,{'error':'Busy; retry shortly'})
        try:
            size=int(self.headers.get('Content-Length','0'))
            limit=28_000_000 if self.path=='/api/upload/batch' else 7_000_000 if self.path=='/api/upload' else 1_000_000
            if not 0<size<=limit: return self.reply(413,{'error':'Request exceeds size limit or is empty'})
            data=json.loads(self.rfile.read(size))
            if not isinstance(data,dict): raise ValueError('Expected a JSON object')
            requested=data.get('use_llm',True)
            if type(requested) is not bool: raise ValueError('use_llm must be a boolean')
            # Live inspection always uses the semantic judge. The pipeline
            # quarantines content if the configured model is unavailable.
            live=True
            if self.path=='/api/model':
                from pif import providers
                return self.reply(200,providers.configure(data.get('provider','openai'),data.get('model'),data.get('api_key')))
            if self.path=='/api/tool': return self.reply(200,guard_tool(data.get('name'),data.get('arguments'),use_llm=True))
            if self.path=='/api/evaluate': return self.reply(200,evaluate())
            if self.path=='/api/session/reset':
                sid=data.get('session_id','')
                if not isinstance(sid,str): raise ValueError('Invalid session ID')
                reset_session(sid); return self.reply(200,{'reset':True})
            if self.path=='/api/agent':
                data['use_llm']=True
                result=run_agent(data); record(result['verdict']); return self.reply(200,result)
            if self.path=='/api/upload/batch':
                from pif.batch import inspect_batch
                result=inspect_batch(data.get('files'),data.get('extraction','local'),live)
                for item in result['results']:
                    if item['status']=='inspected':record(item['verdict'])
                return self.reply(200,result)
            extraction=None
            if self.path=='/api/upload': visible,hidden,source,extraction=extract_upload(data.get('filename'),data.get('content'),data.get('extraction','local'))
            elif self.path=='/api/inspect':
                text=data.get('text',''); source=data.get('source','user'); fmt=data.get('format','text')
                if not isinstance(text,str) or source not in SOURCES: raise ValueError('Invalid text or source')
                if not text.strip(): raise ValueError('Enter content to inspect')
                if fmt not in ('text','html'): raise ValueError('Use text or html format')
                visible,hidden=parse_html(text) if fmt=='html' else (text,'')
            else: return self.reply(404,{'error':'Not found'})
            sid=data.get('session_id')
            verdict=session_inspect(visible,source,hidden,sid,live) if sid else inspect(visible,source,hidden,live)
            from pif.ingestion import enforce_structure
            verdict=enforce_structure(verdict,extraction)
            result=verdict.model_dump(mode='json'); record(result); return self.reply(200,result)
        except (ValueError,TypeError) as e: self.reply(400,{'error':str(e)[:250]})
        except Exception: self.reply(500,{'error':'Inspection failed; content was not forwarded'})
        finally: WORKERS.release()
if __name__=='__main__':
    print('AEGIS / Prompt Injection Firewall: http://127.0.0.1:8765')
    print('Semantic model judge: '+('configured and required' if llm_status()['configured'] else 'not configured; live inputs will be quarantined'))
    server=ThreadingHTTPServer(('127.0.0.1',8765),Handler); server.timeout=20
    server.serve_forever()
