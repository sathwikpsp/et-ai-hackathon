# AEGIS v2.6 — dynamic application and mandatory-requirement analysis

## Command Center behavior

| Section | Live behavior | Data source | Mandatory contribution |
|---|---|---|---|
| Overview | Reads engine/provider status and current in-memory verdict metadata | `/api/health`, `/api/history` | Makes the active firewall and decisions observable |
| Content inspector | Inspects arbitrary pasted content or 1–10 uploaded files and shows evidence, category, structure and forwarding outcome | Caller input only | Implements the primary pre-influence trust boundary across all required sources |
| Agent sandbox | Inspects task/reference, stops rejected content before planning, and searches/summarizes allowed caller content | Caller task and reference only | Demonstrates that the firewall decision controls actual agent/tool flow |
| Session defense | Inspects arbitrary user-entered turns with bounded temporary history | Current session input only | Detects the implemented staged-trigger form of multi-step jailbreak |
| Adversarial lab | Runs the explicitly labeled developer-authored 92-case validation suite | Fixed validation fixtures | Measures regression behavior; does not control live verdicts |
| Architecture | Explains implemented trust boundaries and limitations | Static documentation | Helps reviewers verify alignment; performs no detection itself |

## Hardcoding audit

Removed from the live path:

- Built-in quarterly report and product catalog.
- Synthetic fallback summary after a hostile document is rejected.
- Runtime quick-load attack buttons in Content Inspector, Agent Sandbox and Session Defense.
- Curated-scenario API used to pre-populate live inspection.
- Single-file-only browser behavior.

Fixed data intentionally retained:

- Detector rules, thresholds, allowed tool names, parsing limits and classifier training examples. These are security policy/configuration, not predetermined verdicts. Every live verdict is calculated from submitted content.
- Unit/regression fixtures and the Adversarial Lab corpus. Tests must have fixed expected inputs to detect regressions. They are isolated from live inspection and clearly labeled developer-authored.
- The nine category names and eleven source names from the problem statement.
- Static Architecture documentation.

No live endpoint looks up a filename, sample identifier or test-case answer to choose a verdict. File contents are parsed and inspected at request time.

## Multi-file analysis

`POST /api/upload/batch` accepts `files`, `extraction` and `use_llm`:

```json
{
  "files": [
    {"filename": "report.pdf", "content": "BASE64..."},
    {"filename": "message.eml", "content": "BASE64..."}
  ],
  "extraction": "local",
  "use_llm": false
}
```

Bounds are ten files, 5 MB per file and approximately 20 MB decoded total. Every file receives its own parser/extraction report, action, risk signal, attack types, evidence spans, reason, trace and forwarding payload. One parser failure is withheld without erasing valid results from other files. `safe_files` contains only individually allowed files. The aggregate action reports the worst batch outcome while preserving per-file separation.

## Required attack analysis

For every submitted item, the application reports:

1. Source provenance and extraction method.
2. Whether visible, hidden, encoded, resource-image or structural content was recovered.
3. Decision: allow, quarantine or block.
4. Risk signal and precise decision reason.
5. One or more of the nine required attack categories.
6. Detector name and exact evidence span.
7. Normalization, decoding, local classifier, optional model and enforcement trace.
8. PDF/DOCX/MIME structure findings when applicable.
9. Exact content eligible for agent forwarding, or a quarantine marker.

Encoded attacks preserve both the transport classification and underlying intent. For example, Base64 credential exfiltration returns `encoded_instruction` and `credential_theft`; when supplied through a document source it also returns `indirect_injection`.

## Mandatory-versus-optional scope

The mandatory firewall is Content Inspector plus the extraction, detection, classification and enforcement backend. It accepts the eleven required source families and implements all nine requested categories. Session Defense supports the multi-step category. Agent Sandbox proves pre-planning and pre-tool enforcement.

Optional enhancements are live Gemini/OpenAI/Ollama adjudication, the dashboard, Adversarial Lab, exports, presentation assets and the explanatory Architecture screen. Local mandatory inspection does not depend on a cloud key. A requested optional model that fails cannot convert content into an allow decision.

The defensible rubric position remains D1/F3. F3 is supported because all nine categories have explicit detectors and category assertions. D2/D3 are not claimed without representative independent evaluation and stronger multimodal reliability.
