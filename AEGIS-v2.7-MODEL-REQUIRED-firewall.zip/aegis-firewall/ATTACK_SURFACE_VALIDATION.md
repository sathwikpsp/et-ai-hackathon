# AEGIS v2.5 attack-surface validation

## Direct mapping to Problem 2

| Requirement | Implemented enforcement | Validation evidence |
|---|---|---|
| Intercept incoming content | Inspection occurs before sandbox planning; rejected content becomes a quarantine marker | Agent/browser tests verify rejected originals are not forwarded |
| User messages | Direct input adapter and session analysis | Breadth matrix plus reported five-turn sequence |
| Web pages / HTML | Visible and hidden/comment/attribute streams | Physical HTML fixtures and browser hidden-HTML workflow |
| PDF | Native text, bounded object/xref audit, resource-image OCR, scanned-page OCR | Covered-text, mixed-image and embedded-package fixtures |
| Email | MIME headers, alternatives and bounded attachments | Physical plain/HTML/PDF/opaque attachment fixtures |
| Markdown | Raw-source inspection | Link-title, fence, comment and footnote fixtures |
| Word | Visible/hidden XML runs, comments, headers/footers and package gate | Physical DOCX fixtures |
| API responses | Raw/nested/escaped text normalization | JSON nested/unicode and CDATA fixtures |
| OCR text / images | Normalization plus local Tesseract or opt-in model transcription | Normal, small, rotated and low-contrast image fixtures |
| Source code | Raw string/comment inspection; never executed | Clean/comment/string fixtures; one conservative benign-test rejection |

## Nine required attack classes

Every class is represented by multiple semantic seeds and is asserted as an explicit `attack_types` value, rather than inferred from a generic rejection:

1. `instruction_override`
2. `role_change`
3. `secret_extraction`
4. `tool_abuse`
5. `credential_theft`
6. `context_poisoning`
7. `multi_step_jailbreak`
8. `encoded_instruction`
9. `indirect_injection`

For an encoded credential-theft instruction, for example, the verdict now contains both `encoded_instruction` and `credential_theft`. For the same instruction in a lower-trust document source, it also contains `indirect_injection`. The evidence trail identifies the decoder/rule and decisive substring.

## Matrix construction

- 57 affirmative attack seeds across the seven semantic/action families, including diagnostic/error-channel exfiltration.
- Eleven representations per seed: plain, uppercase, zero-width, Base64, URL percent, hex, ROT13, Unicode escapes, reversed, binary and HTML entities.
- Eleven required source labels.
- 6,897 attack decisions, each checked for rejection and correct underlying category.
- Encoded variants additionally checked for `encoded_instruction`.
- Every non-user source additionally checked for `indirect_injection`.
- Thirty contextual benign controls across eleven sources: 330 decisions checked for allow.
- Total: 7,227/7,227 developer-authored regression cases pass.

The matrix varies representation and source attribution systematically, but its phrases were developed with the implementation. It is regression coverage, not an independent holdout and not proof against arbitrary future paraphrases.

## Depth and feature position

The implementation covers all nine requested class labels, exceeding the seven-class threshold for F3. The defensible depth remains D1/F3 because high multimodal reliability has not been established independently. Physical heterogeneous adapters support a future D2/D3 evaluation, but adapter presence and synthetic success do not by themselves prove D3.

## Remaining attack surface

No detector can guarantee all novel prompt injections. Remaining risks include unseen semantic paraphrases, unsupported languages, OCR loss, text rendered as vector outlines, arbitrary PDF streams, steganography, encrypted/unsupported documents, parser vulnerabilities, persistent-memory paths outside this application, and agents that bypass the firewall integration. Structural uncertainty is quarantined where v2.5 can recognize incomplete inspection.

The optional model prompt performs a nine-category semantic checklist, treats content as data, requires exact grounded evidence, and cannot override deterministic blocks. A requested model failure or truncation quarantines otherwise allowed content. Live inference still requires a working provider/model and was not successfully exercised in the delivered environment.
