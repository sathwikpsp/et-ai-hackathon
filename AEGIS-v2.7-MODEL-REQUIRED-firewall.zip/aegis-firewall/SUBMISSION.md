# AEGIS: Evidence-first Prompt Injection Firewall

**ET × Accenture AI Hackathon — Problem 2: Agentic Cybersecurity**

## Problem and resulting behavior

Untrusted retrieved content can contain instructions that redirect an AI agent toward secret disclosure or unauthorized tools. AEGIS intercepts that content before model context, aggregates inspectable evidence, and withholds hostile items. It then checks every proposed tool call against a strict read-only policy before executing a local sandbox tool. Rejected references stop before planning; the application does not substitute synthetic fallback data.

v2.4 adds contextual intent-and-target guardrails for natural conversational attacks, explicit attack-type/basis reporting, and auditable prior-hostile-context handling in session defense. It distinguishes affirmative harmful action from defensive warnings and incident reporting instead of treating every security word as an attack.

## Self-estimated 9-blocker position

**D1 / F3, conservatively.**

F3 requires at least seven attack types. Implemented detector signals span all nine categories in the brief. Working PDF, Word, HTML and image/OCR ingestion demonstrate heterogeneous input support, but depth D3 also requires a high degree of demonstrable reliability. Our limited synthetic evaluation, OCR recovery limits, small local model and remaining semantic failures do not establish that. D2/D3 are future validation targets, not claims in this submission.

## Structural architecture

```mermaid
flowchart TD
    A[User / web / email / API / source code] --> I[Ingress adapter]
    B[PDF text and metadata] --> I
    C[DOCX runs / hidden text / comments] --> I
    D[Image input via Tesseract OCR] --> I
    I --> N[Bounded normalization and decoding]
    N --> R[Source-aware pattern detectors]
    N --> M[Local trained character-ngram Naive Bayes]
    N --> L[Opt-in Gemini/OpenAI/local Ollama judge]
    N --> S[Bounded ephemeral session context]
    R --> E[Evidence aggregation]
    M --> E
    L --> E
    S --> E
    E --> Q{Policy decision}
    Q -->|allow| P[Original content as untrusted reference]
    Q -->|quarantine or block| X[Whole-item quarantine marker]
    P --> G[Authorized task and agent planner]
    X --> Z
    G --> T{Tool allowlist + exact argument schema + argument inspection}
    T -->|denied| Z[No execution]
    T -->|allowed| U[Search or summarize inspected caller content]
    U --> O[User-visible output and execution trace]
    E --> H[Metadata history + verdict JSON export]
    V[Curated attacks + deterministic adversarial mutations] --> I
    H --> W[Measured outcomes and replay]
```

### Key actions, decisions, and model usage

1. **Ingress:** accept text/HTML or locally extract uploaded text, PDF, DOCX and images. Enforce size/page/expansion/pixel limits. HTML comments, hidden nodes, and auxiliary attribute text are inspected; DOCX hidden runs and comments are separated from visible text. No uploaded program or macro executes.
2. **Normalization:** Unicode NFKC and invisible-character removal; bounded Base64, URL, explicit hex and ROT13 decoding. Detect decoded instructions and preserve decoder attribution.
3. **Evidence:** rules map patterns to attack categories. The inherited 18-example local classifier uses learned character-ngram distributions; its uncalibrated attack-like signal is capped at quarantine strength. Detected instructions from lower-trust sources gain indirect-injection attribution.
4. **Optional live AI:** Configured provider judge receives delimited untrusted data, with no tools. It returns structured attack categories and an exact evidence span. Unknown types, invalid schema, hallucinated evidence, provider errors or unreviewed truncated content cannot yield an allow decision. A benign LLM answer never cancels other detector evidence.
5. **Session analysis:** a bounded previous-message window identifies a staged attack followed by a later execution trigger. Raw context is retained temporarily in memory and can be reset. Session IDs are not authentication.
6. **Policy:** max evidence signal ≥0.75 blocks; ≥0.4 quarantines; otherwise allows. A failed requested judge quarantines even without other detector evidence. Both rejected actions replace the entire item with a quarantine marker.
7. **Agent:** inspect the authorized task and reference separately. Local mode uses an explicit deterministic planner; optional live mode uses an LLM planner. A rejected reference stops before either planner. Allowed output is derived only from caller-supplied inspected content.
8. **Tool boundary:** only `search_content` and `summarize_document`, with exactly one string `query`, are allowed. Re-inspect that argument. Unknown tools, extra arguments or detected injection deny execution. Both tools are bounded and read-only.
9. **Adversarial loop:** generate deterministic mutations, inspect them, compare against developer labels, calculate confusion counts/precision/recall/FPR/P95, and expose failure replay and JSON export. It does not silently retrain or edit enforcement policy.

## Coverage evidence

| Brief attack type | Implemented signal | Working demo or sample |
|---|---|---|
| Instruction override | Rules, semantic similarity, optional judge | Override replay |
| Role change | Persona requests, forged developer/system delimiters | Forged developer replay |
| Secret extraction | Hidden-instruction/system-prompt disclosure rules | Secret replay / PDF sample |
| Tool abuse | Destructive tool/command patterns + default deny | Shell replay / denied `send_email` |
| Credential theft | Credential movement/exfiltration patterns | Email sample / image OCR sample |
| Context poisoning | Trusted-context replacement and memory poisoning patterns | Poisoning replay |
| Multi-step jailbreak | In-item stages and bounded cross-turn trigger analysis | Session defense |
| Encoded instructions | Bounded decoding + detector re-scan | Base64 replay + adversarial variants |
| Indirect injection | Hidden-content and lower-trust source attribution | Hidden HTML / DOCX sample |

The original seed suite plus 54 unit/API/security tests and browser flows validate representative cases. Coverage does not imply complete recall for the category.

## Evaluation and responsible claims

See `VALIDATION.md` and `artifacts/evaluation-results.json`. The enhanced suite contains 92 developer-authored synthetic cases, including encodings, benign safety warnings, quotations and hard evasion cases. Benchmarks were developed alongside detector changes and are not independent holdout evidence. Detection metrics count block or quarantine, not category correctness. Live provider execution is unverified without supplied credentials; mocked tests validate response-grounding and failure handling.

Business value demonstrated: malicious references are withheld, clean caller content remains usable, and unknown or dangerous tool calls are denied. No real enterprise deployment, reduction in breach rates, savings, or production performance is claimed.

## Security, privacy, and deployment boundaries

Local-first, loopback-only service. No user key stored in files; live processing is explicitly selected. History stores verdict metadata, sessions retain bounded raw messages in process memory. JSON exports can include evidence snippets; users choose export. Cross-origin POST requests are rejected. Size bounds, limited processing concurrency and OCR timeout reduce resource risk.

There is no multi-user authentication, persisted audit store, network tool execution, enterprise connector or hardened PDF parsing worker. Images use local OCR or explicit model transcription. Scanned PDF pages use bounded local OCR; Gemini can read the original PDF directly. Small/hidden/rotated/low-contrast content can be missed. Quote-sensitive, multilingual and novel attacks remain open problems. Add authenticated ingress, tenant-isolated state, sandboxed parsers, independently tested semantic models, representative holdout evaluation and real agent SDK integration before production use.

## Submission artifacts

- Complete runnable application and APIs.
- `samples/` with synthetic benign and hostile files.
- `DEMO_SCRIPT.md`: five-minute narration and judge Q&A.
- `artifacts/pitch-deck.pdf`: presentation and architecture.
- `artifacts/evaluation-results.json`: complete measured outcomes.
- `artifacts/browser-qa.json`: observed browser checks.
- `artifacts/*.png`: desktop/mobile screenshots from working app.

## v2.3 verified structural and source coverage

55 physical ingestion fixtures across all 11 formats were executed: 54 passed the defined ingestion/detection/container sub-oracle; one benign source-code test is falsely blocked. PDF native text under an overlaid image and text inside resource images on mixed pages are detected. Embedded ZIP packages, active PDF actions and appended package bytes are quarantined independently of visible rendering. Neither quarantine nor attachment discovery establishes malicious binary classification.

All 100 cases in the supplied deep design are accounted for in `DEEP_TEST_STATUS.md`; partial exercises are not full acceptance passes. Full private-canary agent outcomes, authenticated tenants, streaming, load tests, recipient authorization and independent holdout reliability remain unverified. The local sandbox cannot establish those claims. Keep the conservative D1/F3 claim.
