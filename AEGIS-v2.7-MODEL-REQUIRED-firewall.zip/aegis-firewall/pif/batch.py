"""Bounded multi-file inspection with per-file and aggregate decisions."""
from pathlib import Path

from .ingestion import inspect_upload

MAX_FILES=10
MAX_COMBINED_BASE64=26_800_000  # Approximately 20 MB of decoded input.


def inspect_batch(files,extraction='local',use_llm=False):
    if not isinstance(files,list) or not 1<=len(files)<=MAX_FILES:
        raise ValueError(f'Upload 1–{MAX_FILES} files per batch')
    if extraction not in ('local','model') or type(use_llm) is not bool:
        raise ValueError('Invalid batch inspection options')
    if any(not isinstance(item,dict) for item in files):
        raise ValueError('Each batch item must be an object')
    if sum(len(item.get('content','')) for item in files if isinstance(item.get('content'),str))>MAX_COMBINED_BASE64:
        raise ValueError('Combined files exceed 20 MB')
    results=[];counts={'allow':0,'sanitize':0,'block':0,'error':0};categories=set();max_risk=0.0;latency=0.0;evidence=[]
    for index,item in enumerate(files):
        filename=item.get('filename');content=item.get('content')
        display=Path(filename).name if isinstance(filename,str) else f'file-{index+1}'
        try:
            verdict=inspect_upload(filename,content,extraction,use_llm)
            data=verdict.model_dump(mode='json');counts[data['action']]+=1
            categories.update(data['attack_types']);max_risk=max(max_risk,data['risk']);latency+=data['latency_ms']
            for finding in data['evidence'][:25]:
                evidence.append({**finding,'span':display+': '+finding['span']})
            results.append({'index':index,'filename':display,'status':'inspected','verdict':data})
        except (ValueError,TypeError) as exc:
            counts['error']+=1
            results.append({'index':index,'filename':display,'status':'withheld','error':str(exc)[:250]})
    action='block' if counts['block'] else 'sanitize' if counts['sanitize'] or counts['error'] else 'allow'
    rejected=counts['block']+counts['sanitize']+counts['error']
    reason=(f'{len(files)} files inspected independently: {counts["allow"]} allowed, '
            f'{counts["block"]} blocked, {counts["sanitize"]} quarantined, {counts["error"]} extraction errors. '
            'Only individually allowed files are eligible for forwarding.')
    return {'batch':{'action':action,'risk':max_risk,'total':len(files),'allowed':counts['allow'],'rejected':rejected,
                     'blocked':counts['block'],'quarantined':counts['sanitize'],'errors':counts['error'],
                     'attack_types':sorted(categories),'evidence':evidence[:100],'latency_ms':round(latency,2),
                     'decision_reason':reason},'results':results,
            'safe_files':[{'filename':item['filename'],'content':item['verdict']['sanitized_text']} for item in results if item['status']=='inspected' and item['verdict']['action']=='allow']}
