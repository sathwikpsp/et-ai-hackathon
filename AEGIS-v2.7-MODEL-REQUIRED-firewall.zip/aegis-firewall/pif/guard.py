"""Default-deny tool boundary for the demonstrator."""
from .pipeline import inspect

def guard_tool(name,arguments,use_llm=False):
    if name not in ('search_content','summarize_document'):
        return {'allowed':False,'reason':'Tool is outside the read-only allowlist'}
    if not isinstance(arguments,dict) or set(arguments)!={'query'} or not isinstance(arguments['query'],str):
        return {'allowed':False,'reason':'Expected exactly one string argument: query'}
    v=inspect(arguments['query'],source='tool_arguments',use_llm=use_llm)
    return {'allowed':v.action.value=='allow','reason':'Content inspection: '+v.action.value}
