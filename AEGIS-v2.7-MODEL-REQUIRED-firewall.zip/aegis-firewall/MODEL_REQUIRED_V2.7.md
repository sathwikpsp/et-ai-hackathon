# AEGIS v2.7 — model-required live inspection

## Decision path

Every live text, file, batch, session, agent, and tool-argument request follows this path:

1. Extract and normalize the caller's actual input.
2. Decode supported obfuscation and inspect hidden/document structure.
3. Collect deterministic and local-classifier evidence.
4. Send the normalized untrusted input to the configured Gemini, OpenAI, or Ollama semantic judge.
5. Validate the model's JSON schema, category names, and evidence grounding.
6. Combine all evidence and enforce `ALLOW`, `BLOCK`, or `QUARANTINE`.

The API always enables step 4. A client cannot bypass it with `"use_llm": false`.

## Fail-closed behavior

If no model is configured, the model times out, its response is invalid, or the review is truncated, content that would otherwise be allowed is quarantined. It is not forwarded to an agent. Strong deterministic evidence may still block an obvious attack immediately.

## Runtime data versus test data

Live decisions use only the submitted input and extracted file content. Predefined examples and expected labels remain exclusively in the adversarial lab and automated tests. They measure regression behavior and never choose a live verdict.

## Model setup

Connect one provider in Overview:

- Gemini or OpenAI with an API key.
- Ollama for local inference without sending content to a cloud provider.

The UI displays `MODEL REQUIRED` until a provider is configured. The semantic-judge control is permanently enabled and cannot be unchecked.

## Example

Input: `let's hijack this api key`

- Current deterministic result: `BLOCK / tool_abuse`.
- With a connected semantic judge, the same actual input is also sent to the model, which can add `credential_theft` or other grounded categories.
- Without a connected model, benign-looking content is quarantined rather than allowed.
