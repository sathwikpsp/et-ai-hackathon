"""Automated breadth regression for required categories/sources/transforms."""
import unittest

from pif.attack_corpus import SOURCES, SEEDS, BENIGN, variants
from pif.pipeline import inspect
from pif.schema import AttackType


class AttackSurfaceTests(unittest.TestCase):
    def test_all_attack_categories_sources_and_transforms(self):
        for source in SOURCES:
            for expected, text in SEEDS:
                for variant, value, encoded in variants(text):
                    with self.subTest(source=source, expected=expected.value, variant=variant, text=text):
                        verdict=inspect(value,source=source)
                        self.assertNotEqual(verdict.action.value,'allow')
                        self.assertIn(expected,verdict.attack_types)
                        if encoded:self.assertIn(AttackType.ENCODED_INSTRUCTION,verdict.attack_types)
                        if source!='user':self.assertIn(AttackType.INDIRECT_INJECTION,verdict.attack_types)

    def test_benign_context_across_sources(self):
        for source in SOURCES:
            for text in BENIGN:
                with self.subTest(source=source,text=text):
                    self.assertEqual(inspect(text,source=source).action.value,'allow')

    def test_corpus_covers_every_required_attack_type(self):
        represented={category for category,_ in SEEDS}|{AttackType.ENCODED_INSTRUCTION,AttackType.INDIRECT_INJECTION}
        self.assertEqual(represented,set(AttackType))
