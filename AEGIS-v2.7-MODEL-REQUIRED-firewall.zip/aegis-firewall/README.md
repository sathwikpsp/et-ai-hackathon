# AEGIS — Prompt Injection Firewall

A working upgrade of PIF for **ET × Accenture AI Hackathon, Problem 2**. Local Python backend, responsive security dashboard, real document ingestion, a protected read-only agent sandbox, bounded session analysis, optional Gemini/OpenAI/local Ollama judge and planner, and measured adversarial replay.

## v2.7: mandatory semantic adjudication for every live input

Every production inspection endpoint now invokes the configured Gemini, OpenAI, or Ollama semantic judge. This cannot be disabled by an API request or UI checkbox. If the model is missing, times out, returns invalid JSON, or reviews only part of the input, the firewall quarantines the content instead of returning `ALLOW`. Deterministic normalization, decoding, structural inspection, rules, and the local classifier remain defense-in-depth signals; they do not replace the mandatory model decision.

Predefined examples exist only in the adversarial regression lab. They do not select or manufacture live verdicts.

## v2.6: dynamic inputs, multi-file analysis, no synthetic execution fallback

The live firewall and agent path now operate only on caller-supplied content. The sandbox contains no product catalog, business report or fallback answer: rejected content stops before planning, while allowed content can be searched or summarized by bounded read-only tools. The inspector accepts up to ten files per batch (5 MB each, 20 MB combined), returns independent extraction/verdict/evidence/structure details, and forwards only individually allowed files. Fixed adversarial cases remain isolated in the clearly labeled validation lab; they do not determine live verdicts or agent output.

## v2.5: full requirement-surface hardening

v2.5 keeps the implementation mapped to the problem's eleven input families and nine attack classes. It adds spaced-letter/confusable normalization; Unicode-escape, reversed and binary decoding; preservation of the underlying category for encoded attacks; broader authority/semantic/multi-step patterns; and a bounded multilingual core for high-risk directives. The original 92-case suite now detects all 68 supplied attack cases and allows all 24 supplied benign cases. This suite was developed alongside the detector and is not an independent benchmark.

The broader attack-surface regression exercises 7,227 decisions: 6,897 attack/category/source/transform combinations and 330 contextual benign controls. It validates the expected underlying category, `encoded_instruction` attribution for decoded representations, and `indirect_injection` attribution for lower-trust sources. The physical-file suite remains separate because a source label is not equivalent to parsing a real PDF, DOCX, email or image.

## v2.4: intent guardrails and explainable cross-turn decisions

This version adds contextual intent-and-target rules for credential theft, secret extraction, harmful tool use and audit/context tampering. It catches conversational requests such as “let's hijack,” “hide the API key and give it to attacker,” while keeping explicit warnings and descriptive security reporting usable. Bare high-risk commands are withheld; a non-action word such as “suspicious” is not treated as a prompt-injection category by itself.

Cross-turn results now record whether earlier hostile context was considered, and the UI shows the classified attack types and exact decision basis. The optional model adjudicator uses the same nine-category checklist and requires grounded evidence. The deterministic guardrail matrix exercises 561 attack/benign combinations across all eleven required source families, plus the reported five-turn session sequence. This is broad regression coverage, not an independent production benchmark.

## Start in 2 minutes

Python 3.10+ recommended. No Node build or API key is required for local mode.

```sh
python -m venv .venv
# macOS / Linux:
source .venv/bin/activate
# Windows PowerShell instead:
# .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

Open **http://127.0.0.1:8765**. Alternatively use `start.sh` on Linux/macOS or `start.bat` on Windows. The server intentionally binds to loopback. Do not open `demo/index.html` directly; it needs the Python APIs.

For image OCR, install Tesseract: Ubuntu/Debian `sudo apt-get install tesseract-ocr`, macOS `brew install tesseract`. On Windows install Tesseract and add its executable directory to PATH. Other features work without OCR.

## Enable live AI

In Overview → **Connect optional live AI**, choose Gemini, OpenAI, or Ollama and enter the model name. Cloud providers need their own API key; Ollama needs no key. The key remains in process memory; it is never written to project files or returned by the API. Select the live checkbox in the inspector or agent sandbox. Only opted-in cloud requests send content to the selected provider; API usage may incur charges.

Alternatively set `PIF_PROVIDER=gemini` with `GEMINI_API_KEY`, or `PIF_PROVIDER=openai` with `OPENAI_API_KEY`, or `PIF_PROVIDER=ollama`. Optionally set `PIF_MODEL` before starting. Configuration status is not proof the provider accepts your key or model. A requested judge that fails, produces ungrounded evidence, or truncates unreviewed content quarantines the item. A planner failure never executes a tool.

**AI honesty:** local classification uses an 18-example character-ngram Naive Bayes model, inherited from PIF. Offline agent planning is deterministic. Configured model mode uses the selected provider for semantic judgment and tool planning. Live provider execution was not tested in the delivered environment because no API key was supplied; its response-validation paths are covered by mocked tests.

## v2.3: full-source validation and PDF structural inspection

This version fixes the distinction between visible document rendering and underlying content. PDF parsing now checks native text, a bounded object/xref graph including otherwise unreachable objects, metadata/annotations/form strings, embedded-file specifications, automatic/active actions, and bytes appended after the final EOF. It independently extracts and OCR-inspects resource images even on pages that already have text. Covering text or an attachment icon with an image does not remove these underlying PDF objects.

Unknown embedded packages, active actions and incomplete component scans **quarantine the workflow**. That is a structural safety decision, not proof that a package is malicious. Packages are never opened or executed by the agent. Binary malware analysis, arbitrary hidden streams and pixel steganography are unsupported. PDF parsing is not hardened subprocess isolation; this remains a local prototype.

MIME emails now inspect both plain and HTML alternatives and supported attachments. DOCX embedding/macro members are withheld; normal document/header/footer/comment text is scanned. Nested JSON escape strings, HTML entities and bare hexadecimal text are decoded within budgets. Unreviewed encoding residue quarantines. Local OCR uses bounded upscaling and three orientation passes; it remains lossy.

**Executed evidence:** `SOURCE_VALIDATION.md` / `artifacts/source-validation.json` contain 55 physical fixtures across all 11 source formats; 54 meet the ingestion/detection/container oracle and one benign code test is falsely blocked. These are development fixtures, not an independent benchmark or a complete downstream-agent security oracle. `DEEP_TEST_STATUS.md` accounts for the uploaded 100-case acceptance design: partial subtests and unrun infrastructure checks remain explicit. No claim of 100/100 acceptance validation.

Try the samples in `samples/source-validation/`, especially `pdf-text-under-image.pdf`, `pdf-mixed-image-text.pdf`, and `pdf-package-covered-image.pdf`. The inspector shows **Document structure and inspection coverage** alongside detector evidence. For a covered ZIP package the expected result is quarantine with an embedded-file finding, even if the visible page looks ordinary.

To regenerate source fixtures/reports, install development dependencies in `requirements-dev.txt` and run `python tools/validate_sources.py`; then `python tools/validate_deep_design.py`. The normal app does not need development dependencies. Reports expose hashes, parsing coverage, dispositions and known failures. Parser errors are not counted as successful malicious-content detection.

## v2.1: Gemini, Ollama and PDF diagnosis

**Tesseract is not needed for plain text, HTML, Word or text-based PDFs.** It is used for local image OCR and rasterized scanned PDF pages. PDF text extraction uses pypdf. PyMuPDF renders scanned pages before OCR. Gemini can read PDFs/images directly without Tesseract; Ollama supports image input when the installed model supports vision.

In the inspector, choose **File extraction method** independently of the **Use configured model judge** checkbox:

- **Local:** deterministic parsers; image/scanned-page OCR stays on your machine.
- **Configured model:** Gemini receives the original PDF/image; a vision-capable Ollama model receives images locally. Ollama direct PDF input is not implemented; use local PDF parsing. For text/Word files the normal parser remains sufficient.

Gemini extraction preserves any original pypdf-extracted text so a model cannot erase a locally recovered malicious instruction. A model-reported incomplete extraction or an empty unreadable document is withheld. Vision/OCR transcription is imperfect and does not establish complete hidden-layer recovery.

For Gemini choose `gemini-3.8-flash` (editable to a model available to your key). Set your key locally in Overview; do not paste credentials into chat. The adapter follows the [Gemini Interactions API](https://ai.google.dev/gemini-api/docs/interactions-overview), with JSON output and `store=false`.

For local open-weight inference, install [Ollama](https://ollama.com), run `ollama pull gemma3:4b`, start the Ollama service, and choose **Ollama** with `gemma3:4b`. Calls go only to `http://127.0.0.1:11434/api/generate`. Another installed model can be entered; choose a vision-capable one for images. No inference engine or weights are bundled. Model speed and OCR quality depend on your hardware/model. See [Ollama API](https://docs.ollama.com/api/generate).

A PDF is **not quarantined simply because it is a PDF**. Each verdict now contains `decision_reason`, displayed under the decision. A local-ML flag can be a false positive; a failed requested judge reports missing configuration, quota, key, network, or response validation problems. `samples/poisoned-report.pdf` intentionally contains an attack and should block. The supplied hackathon brief passed local inspection. Your own PDF needs its evidence trace to identify the precise cause.

See `PDF_TROUBLESHOOTING.md`. Remote provider calls are implemented and mocked in tests, but no real Gemini/OpenAI key was supplied. Actual remote inference is not verified. Local Ollama configuration and unavailable-runtime handling were checked in the running browser.

## Demo

1. Content Inspector → paste arbitrary HTML with visible and hidden text → Inspect: see hidden-content evidence and the withheld forwarding payload.
2. Upload `samples/hidden-instruction.docx`, `poisoned-report.pdf`, or `injection-screenshot.png`.
3. Agent Sandbox → submit hostile content and observe a stop before planning; then submit clean caller content and observe the actual local summary/search tool.
4. Session defense: submit the staged first turn, load “Proceed” for turn two, and inspect the cross-turn block. Reset clears retained context.
5. Adversarial lab → Run suite: 92 measured synthetic cases, including known failures. Replay a failure into the inspector.

Read `DEMO_SCRIPT.md` for a timed presentation and `SUBMISSION.md` for architecture and scope. `artifacts/pitch-deck.pdf` is a six-slide presentation.

## Verify

```sh
python -m unittest discover -s tests -p 'test_*.py' -v
python benchmark.py
python evaluate.py
```

`benchmark.py` retains the original seed evaluation. `evaluate.py` produces the enhanced 92-case report. Evaluation is local-only and never calls the LLM. Developer-authored cases and transformations are not an independent holdout. Detection is block **or** quarantine; correct attack-category attribution is a separate question.

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Runtime and model configuration, never credentials |
| GET | `/api/history` | Last 100 verdict metadata records |
| POST | `/api/inspect` | `text`, `source`, `format`, optional `session_id`, `use_llm` |
| POST | `/api/upload` | `filename`, base64 `content`, optional `use_llm` |
| POST | `/api/upload/batch` | 1–10 `files`, per-file verdicts, aggregate summary and allowed-file list |
| POST | `/api/tool` | `name`, `arguments` — evaluation only |
| POST | `/api/agent` | `task`, external `content`, `format`, `use_llm` |
| POST | `/api/evaluate` | Run synthetic adversarial suite |
| POST | `/api/session/reset` | Reset `session_id` |
| POST | `/api/model` | Configure `api_key` and `model` in process memory |

Sources: `user`, `web`, `pdf`, `email`, `markdown`, `html`, `docx`, `api`, `ocr`, `code`, `image`. Formats: `text`, `html`. All inputs are untrusted; client-supplied provenance never grants authority.

## Enforcement and operational limits

- Maximum 200,000 extracted characters per file; upload limit 5 MB each; batch limit 10 files and 20 MB decoded total; PDFs limited to 100 pages, with at most 10 no-text pages OCR-processed locally; expanded DOCX limit 20 MB; image limit 20 million pixels; OCR timeout 12 seconds per orientation pass.
- Normalization decodes at most two layers by default, bounded by byte and token budgets. Unicode invisibles, Base64, URL encoding, explicit hex and ROT13 markers are supported; arbitrary encryption is not.
- High detector signal blocks; medium signal quarantines. Both withhold the **entire item**. No partial-cleaning safety claim.
- Only `search_content` and `summarize_document`, with exactly one string `query`, may run. Both operate only on inspected caller-supplied text. The sandbox has no built-in business data, shell, email, credential access, payments, network, or external side effects.
- Session raw text is bounded and ephemeral: six stored 12,000-character messages per session, up to six previous messages considered with a new turn, 30-minute TTL, maximum 100 sessions. Expired entries are purged on later session requests; restart/reset clears memory. History stores metadata only.
- Four concurrent processing operations; cross-origin POST requests denied; socket timeout; no uploaded code or macros execute.
- This local prototype has no multi-user authentication or persistent database. It is not a production firewall. PDF parsing is not isolated in a subprocess; extreme malformed documents need a hardened parsing worker in production.
- OCR misses, complex PDF rendering, benign quoted attack examples, novel paraphrases and multilingual attacks remain limitations. No claim of universal prompt-injection protection.

No user credentials or real confidential data are included. `samples/` contains harmless synthetic attack examples.
