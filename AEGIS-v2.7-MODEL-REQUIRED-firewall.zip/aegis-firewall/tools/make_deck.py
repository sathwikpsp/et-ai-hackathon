"""Optional presentation generator. Requires reportlab (not a runtime dependency)."""
import json
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/pitch-deck.pdf'
W,H=960,540
BG='#0a0d14';PANEL='#151b27';LINE='#2b3545';WHITE='#edf1f7';MUTED='#9aa7bd';PURPLE='#aa9aff';GREEN='#7ce1b3';RED='#ff919b'
c=canvas.Canvas(str(OUT),pagesize=(W,H));c.setTitle('AEGIS — Prompt Injection Firewall');c.setAuthor('ET AI Hackathon team')
def text(x,y,value,size=14,color=WHITE,bold=False):
 c.setFillColor(HexColor(color));c.setFont('Helvetica-Bold' if bold else 'Helvetica',size);c.drawString(x,y,value)
def lines(x,y,values,size=14,color=MUTED,spacing=23):
 for i,v in enumerate(values):text(x,y-i*spacing,v,size,color)
def panel(x,y,w,h):
 c.setFillColor(HexColor(PANEL));c.setStrokeColor(HexColor(LINE));c.roundRect(x,y,w,h,10,stroke=1,fill=1)
def base(n,label,title,sub=''):
 c.setFillColor(HexColor(BG));c.rect(0,0,W,H,stroke=0,fill=1)
 text(42,H-38,'AEGIS / AGENT SECURITY LAB',11,PURPLE,True);text(W-227,H-38,'ET x ACCENTURE / PROBLEM 02',9,MUTED)
 text(42,H-90,label.upper(),10,PURPLE);text(42,H-129,title,29,WHITE,True)
 if sub:text(42,H-155,sub,12,MUTED)
 c.setStrokeColor(HexColor(LINE));c.line(42,38,W-42,38);text(42,22,'AI Hackathon - Agentic Edition | AEGIS v2.3 | Working local prototype',9,MUTED);text(W-62,22,str(n),10,PURPLE)
def end():c.showPage()
def box(x,y,w,h,head,body):
 panel(x,y,w,h);text(x+18,y+h-30,head,15,WHITE,True);lines(x+18,y+h-58,body,11,spacing=18)
base(1,'Agentic cybersecurity','Let agents work. Keep attacks out.','A prompt injection firewall that protects context and constrains tool execution.')
box(42,220,415,112,'The risk',['External documents contain attacker instructions.','An agent may mistake untrusted data for authority.','Tool access turns a redirected answer into a real action.'])
box(477,220,441,112,'The result',['Inspect before content enters the planner.','Withhold hostile items; continue safe tasks with trusted data.','Re-check every proposed tool before local execution.'])
text(42,156,'INPUT',11,MUTED);text(235,156,'FIREWALL',11,PURPLE);text(480,156,'PLANNER',11,MUTED);text(715,156,'TOOL GATE',11,GREEN)
text(42,125,'Documents + OCR',18);text(235,125,'Evidence + policy',18);text(480,125,'Safe context',18);text(715,125,'Read-only actions',18)
text(42,70,'Local ML without a key. Optional Gemini, OpenAI or local Ollama judgment. Both enforce the same tool boundary.',12,MUTED);end()
base(2,'Working demonstration','A cover image cannot hide the PDF structure.','v2.3 inspects native text, PDF objects, embedded resources and rendered-page OCR.')
img=ROOT/'artifacts/pdf-structure-browser.png'
if img.exists():
 im=ImageReader(str(img));iw,ih=im.getSize();scale=min(535/iw,300/ih);c.drawImage(im,42,75,width=iw*scale,height=ih*scale)
box(600,242,318,115,'Three verified PDF scenarios',['Text under a cover image: blocked.','Image instructions + native text: blocked.','Covered embedded ZIP: quarantined.'])
box(600,90,318,126,'Enforced before context',['Native text + resource OCR expose instructions.','Object inspection flags embedded packages.','Original rejected content stays withheld.','Package quarantine is not malware diagnosis.']);end()
base(3,'AI and autonomous execution','Useful work, within enforced permissions.','Show the real path in Agent sandbox and the staged trigger in Session defense.')
box(42,203,282,155,'1 / Semantic inspection',['Trainable character-ngram local model.','18 synthetic training examples; limited scope.','Optional Gemini / OpenAI / Ollama judge returns','validated categories + grounded evidence.','Requested judge failure quarantines.'])
box(339,203,282,155,'2 / Agent planning',['Local deterministic planner or live LLM.','Rejected external content never forwarded.','Safe task can use a trusted fallback report.','Live planning proposes a JSON tool call.','Tool failure never becomes execution.'])
box(636,203,282,155,'3 / Tool enforcement',['Two local read-only tools only.','Exact name and argument schema.','Query inspected before tool execution.','Unknown / dangerous tools denied.','Catalog and summary actually execute.'])
text(42,143,'Cross-turn defense',17,GREEN,True);lines(42,115,['Earlier staged exfiltration + later "Proceed" triggers a context-aware block.','Reset proves the same isolated trigger passes without retained attack context.'],13,spacing=22)
text(42,63,'Live provider run is unverified without credentials. Local mode and provider-failure paths were tested.',11,MUTED);end()
base(4,'Structural architecture','Two boundaries, one inspectable trace.','Ingest -> normalize -> detect -> enforce -> plan -> guard -> execute.')
headers=['Ingress + extract','Normalize + decode','Aggregate evidence']; bodies=[['Text / web / email / API','PDF / DOCX / image OCR'],['Unicode / Base64 / URL','Explicit hex / ROT13'],['Rules / local ML / live judge','Bounded session context']]
for i in range(3):box(42+i*297,235,282,112,headers[i],bodies[i])
for i in range(2):text(328+i*297,282,'>',14,PURPLE)
headers=['Allow or quarantine','Protected planning','Read-only execution'];bodies=[['Evidence thresholds; whole item','Failure of requested judge: quarantine'],['Authorized task + safe reference','Local or optional LLM planner'],['Allowlist + schema + query inspection','Execute sandbox tool or deny']]
for i in range(3):box(42+i*297,85,282,112,headers[i],bodies[i])
for i in range(2):text(328+i*297,132,'>',14,GREEN)
text(436,212,'v',15,PURPLE);end()
r=json.loads((ROOT/'artifacts/evaluation-results.json').read_text())
base(5,'Measured evidence','Test the defenses. Show the failures.','92 developer-authored synthetic cases; deterministic adversarial mutations and hard stress cases.')
for i,(head,value,caption) in enumerate([('PRECISION',f"{r['precision']*100:.1f}%",'65 true attacks / 65 detections'),('RECALL',f"{r['recall']*100:.1f}%",'65 detected / 68 attacks'),('FALSE POSITIVE RATE',f"{r['false_positive_rate']*100:.1f}%",'0 false positives / 24 benign')]):
 x=42+i*297;panel(x,229,282,117);text(x+18,318,head,10,MUTED);text(x+18,272,value,32,PURPLE,True);text(x+18,246,caption,11,MUTED)
lines(42,190,['70 regression tests passed. 55 source fixtures across 11 formats: 54 pass, 1 false positive.','Browser verified: covered PDF text, embedded package quarantine, DOCX and image OCR.','Known limits: multilingual / novel semantic attacks; benign source-code fixture is falsely blocked.'],13,spacing=27)
text(42,80,'Not an independent holdout. Detection is block or quarantine, not category correctness or production safety.',11,RED)
text(42,61,'Supplied 100-case acceptance design: 70 partial, 1 fail, 29 not run; no full end-to-end pass claim.',10,MUTED);end()
base(6,'Defensible scope and next step','A working F3 prototype. An honest depth claim.','Self-estimated 9-blocker position: D1 / F3, conservatively.')
box(42,207,415,142,'Demonstrated today',['Nine implemented attack-category signals.','Heterogeneous document ingestion and image OCR.','Cross-turn trigger analysis and evidence exports.','Two enforced trust boundaries and real local tools.','Measured adversarial replay with visible failure cases.'])
box(477,207,441,142,'Required before D2 / D3 and production',['Independent, representative holdout evaluation.','Stronger semantic / multilingual model validation.','Authenticated tenant isolation and real agent integration.','Hardened parser workers and durable audit trails.','Comprehensive multimodal recovery and evasion tests.'])
text(42,148,'Why this matters',18,GREEN,True);lines(42,117,['Agents stay useful while untrusted documents lose their authority.','Security decisions are visible, testable and enforced again before action.'],15,WHITE,spacing=27)
text(42,65,'AEGIS: stop data from becoming authority.',19,PURPLE,True);end()
c.save();print(OUT)
