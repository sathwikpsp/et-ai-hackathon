"""Validate all categories, source labels and supported obfuscation variants."""
import json
import sys
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from pif.attack_corpus import SOURCES,SEEDS,BENIGN,variants
from pif.pipeline import inspect
from pif.schema import AttackType

results=[];summary=Counter()
for source in SOURCES:
    for expected,text in SEEDS:
        for variant,value,encoded in variants(text):
            verdict=inspect(value,source=source)
            types=set(verdict.attack_types)
            passed=verdict.action.value!='allow' and expected in types
            if encoded:passed=passed and AttackType.ENCODED_INSTRUCTION in types
            if source!='user':passed=passed and AttackType.INDIRECT_INJECTION in types
            summary['attack_total']+=1;summary['attack_passed']+=passed
            results.append({'source':source,'variant':variant,'label':'attack','expected_type':expected.value,'decision':verdict.action.value,'types':sorted(t.value for t in types),'reason':verdict.decision_reason,'passed':bool(passed),'text':text})
    for text in BENIGN:
        verdict=inspect(text,source=source);passed=verdict.action.value=='allow'
        summary['benign_total']+=1;summary['benign_passed']+=passed
        results.append({'source':source,'variant':'plain','label':'benign','expected_type':None,'decision':verdict.action.value,'types':sorted(t.value for t in verdict.attack_types),'reason':verdict.decision_reason,'passed':passed,'text':text})
report={'version':'2.5','scope':'Developer-authored breadth regression; not an independent benchmark or proof against novel attacks.','sources':list(SOURCES),'seed_attacks':len(SEEDS),'variants_per_attack':len(variants(SEEDS[0][1])),'benign_phrases':len(BENIGN),**summary,'total':len(results),'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results),'failures':[r for r in results if not r['passed']],'results':results}
(ROOT/'artifacts/attack-surface-v2.5.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:report[k] for k in ('total','passed','failed','attack_total','attack_passed','benign_total','benign_passed')},indent=2))
if report['failed']:raise SystemExit(1)
