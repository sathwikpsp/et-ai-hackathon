# Validation — AEGIS v2

Validation was run in the supplied Linux environment with Python 3.12, Node 24 for JavaScript syntax, installed Pillow/pypdf/Pydantic, Tesseract, and Chromium headless.

## Functional/security suite

**40 tests passed** with:

```sh
python -m unittest discover -s tests -p 'test_*.py' -v
```

Includes original regression tests plus URL/hex/ROT13/nested Base64 decoding, hidden HTML attribute and semantic findings, negated credential warnings with a subsequent malicious directive, source attribution, session isolation/reset/bounds, text and hidden DOCX uploads, document expansion and malformed input rejection, actual agent output on clean and quarantined references, catalog search, no execution on unsafe tasks, dangerous planner tool denial, requested-judge fail-closed behavior, grounded versus hallucinated evidence, no model override of rule blocks, truncated judge review, API type validation, cross-origin denial, and evaluation accounting.

## Browser end-to-end

**13 checks passed, zero JavaScript errors.** See `artifacts/browser-qa.json`.

Checked desktop Overview and model status; hidden HTML scan/quarantine; uploaded PDF, hidden DOCX and image OCR; protected agent execution and clean-report execution; two-turn session detection and reset; 92-case evaluation, failure filter and replay; denied email tool; 390px mobile layout without horizontal overflow.

Screenshots are in `artifacts/`. Optional reproduction requires Playwright and its Chromium runtime:

```sh
python -m pip install playwright
python -m playwright install chromium --only-shell
# Start app.py in another terminal, then:
python tools/browser_qa.py
```

## Enhanced synthetic evaluation

92 cases, generated and measured by `evaluate.py` and `/api/evaluate`:

| Measure | Observed value |
|---|---:|
| True positives | 65 |
| True negatives | 21 |
| False positives | 3 |
| False negatives | 3 |
| Precision | 95.6% |
| Recall | 95.6% |
| False positive rate | 12.5% |
| Accuracy | 93.5% |
| P95 local detector processing | Approximately 0.17 ms in the recorded run |

Latency varies by host, content and warm state. It excludes file extraction, browser/network overhead, live LLM calls, and downstream agent work.

Known false positives: benign quoted attack examples and phrase examples. Known misses: a novel paraphrase, Spanish instructions, and a short authority-forgery variant. These cases remain in the report and the UI, rather than being removed to inflate performance.

The original seed benchmark is retained separately in `benchmark-results.json`; it is a smaller development fixture set. The 92-case suite is also developer-authored and was developed alongside detector changes. Neither is an independent holdout or evidence of production-grade reliability. Detection counts block or quarantine, not exact category correctness.

## Live AI verification boundary

No live provider credentials were supplied. OpenAI judge and planner integration exists, but real provider/model acceptance, live latency, and live semantic improvement are **not verified**. Mocked tests exercise schema validation, evidence grounding, tool denial and fail-closed paths. The dashboard distinguishes configuration from actual completed judge execution in each trace.

## Operational scope

OCR was verified on the included clear, high-contrast synthetic screenshot. This does not establish resilience to low contrast, layout manipulation or small/rotated text. PDF extraction and DOCX parsing were tested on representative synthetic samples, not a comprehensive malformed-document corpus. The service is a loopback prototype, not authenticated multi-user hosting.

## v2.1 provider and PDF update

54 functional/security tests pass. Added tests cover Gemini JSON request/response shapes, storage opt-out, grounded evidence and quota errors, local Ollama JSON/image requests without credentials, unsupported direct Ollama PDFs, incomplete vision output withholding, preservation of original PDF instructions alongside model transcription, ordinary text/PDF independence from Tesseract, and rejection of empty unreadable PDF bodies despite metadata.

Original 13 browser checks still pass. Five additional browser checks passed for Gemini/Ollama selector behavior, local configuration without a key, actual unavailable-Ollama fail-closed reason, stale verdict clearing on unsupported model extraction, and a scanned PDF upload recovered by Tesseract. See `artifacts/provider-browser-qa.json` and `artifacts/scanned-pdf-check.json`.

No live Gemini/OpenAI inference or successful local Ollama inference was executed: no cloud key or installed local model was available. Provider request/validation paths were tested with mocks. Local Tesseract scanned-PDF OCR executed successfully on the supplied high-contrast synthetic sample.

## v2.2 Windows encoding and visual fix

HTML is explicitly read and transmitted as UTF-8; the page source is also entirely ASCII using HTML entities and JavaScript escapes. This prevents cp1252 mojibake even on the older server. Six navigation symbols were replaced with inline SVG icons. Windows font fallbacks, color contrast, spacing and card layouts were refined. All 54 tests and 13 original browser flows pass. Four additional checks verified cp1252/UTF-8 transport equivalence, absence of mojibake, SVG icons, desktop/mobile overflow and no JavaScript errors. Native Windows execution was not available; the relevant cp1252 decode path was checked directly.

## v2.3 executed regression and ingestion tests

70 unit/API/security tests pass, including the new PDF cover/image/package/active-action/trailing-data regressions, MIME alternatives/attachments, DOCX packages, nested JSON, OCR ambiguity, residual encoding withholding and scoped user-requested quote analysis. 55 physical fixtures exercise the 11 source-format paths; 54 pass and the benign source-code test false-positive remains. Structural package rejection is distinguished from confirmed content detection. Full execution details and hashes are in `artifacts/source-validation.json`.

The uploaded 100-case design has 70 partial exercises, one failing source-utility subtest and 29 cases not run; zero cases are certified as full acceptance passes. The full downstream canary/tool/memory oracle was not implemented. `artifacts/deep-design-results.json` records each case and its remaining scope. This is separate from the regression tests and from the 92-case synthetic suite.

OCR improved on the specific small/rotated fixtures, not all possible typography or images. No steganography or binary malware classification was performed. File parser resource limits are not process isolation.
