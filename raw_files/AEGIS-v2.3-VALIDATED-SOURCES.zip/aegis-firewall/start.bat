@echo off
cd /d "%~dp0"
if not exist .venv python -m venv .venv
if errorlevel 1 goto error
.venv\Scripts\python -m pip install -r requirements.txt
if errorlevel 1 goto error
.venv\Scripts\python app.py
pause
exit /b
:error
echo Setup failed. Install Python 3.10+ and add it to PATH, then retry.
pause
exit /b 1
