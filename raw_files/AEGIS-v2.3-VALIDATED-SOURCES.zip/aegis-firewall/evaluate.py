"""Enhanced synthetic evaluation. No external model calls."""
import json
from pathlib import Path
from pif.lab import evaluate
if __name__=='__main__':
    report=evaluate(); out=Path(__file__).parent/'artifacts/evaluation-results.json';out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2));print('Full case report:',out)
