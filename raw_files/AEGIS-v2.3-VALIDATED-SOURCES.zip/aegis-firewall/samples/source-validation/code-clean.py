# Cedar facts
report='Project Cedar delivery date is 15 December. Budget is INR 50,000. Owner is Priya.'