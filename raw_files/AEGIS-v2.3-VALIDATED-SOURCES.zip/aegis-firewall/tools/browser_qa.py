import json,pathlib
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1]; artifacts=root/'artifacts';errors=[];checks=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1040},device_scale_factor=1)
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8765');page.wait_for_selector('text=Local engine online')
 page.screenshot(path=str(artifacts/'dashboard.png'),full_page=True)
 checks.append('Overview loads; runtime and model status reflect API')
 page.locator('#quick-hidden').click();page.locator('#scan').click();page.wait_for_function("()=>document.getElementById('scanstatus').textContent==='Inspection complete'")
 assert page.locator('#verdictword').inner_text()=='BLOCK'
 assert 'quarantined' in page.locator('#safe').inner_text();checks.append('Hidden HTML blocked; no hostile text forwarded')
 page.screenshot(path=str(artifacts/'inspector.png'),full_page=True)
 for filename in ['poisoned-report.pdf','hidden-instruction.docx','injection-screenshot.png']:
  page.locator('#file').set_input_files(str(root/'samples'/filename))
  page.wait_for_function("()=>document.getElementById('scanstatus').textContent==='File inspection complete'",timeout=30000)
  assert page.locator('#verdictword').inner_text()=='BLOCK', filename
  assert filename in page.locator('#extraction').inner_text()
  checks.append('Upload '+filename+' extracted and blocked')
 page.locator('[data-view="agent"]').click();page.locator('#run-agent').click();page.wait_for_function("()=>document.getElementById('agent-status').textContent==='Execution complete'")
 assert page.locator('#agent-result-status').inner_text()=='PROTECTED'
 assert '12%' in page.locator('#agent-output').inner_text();assert 'No' in page.locator('#agent-forwarded').inner_text()
 checks.append('Protected agent quarantines attack and executes local summary tool')
 page.screenshot(path=str(artifacts/'agent-sandbox.png'),full_page=True)
 page.locator('#agent-benign').click();page.locator('#run-agent').click();page.wait_for_function("()=>document.getElementById('agent-status').textContent==='Execution complete'")
 assert page.locator('#agent-result-status').inner_text()=='COMPLETED';checks.append('Clean retrieved report forwarded and summarized')
 page.locator('[data-view="session"]').click();page.locator('#send-turn').click();page.wait_for_function("()=>document.getElementById('session-status').textContent==='Turn 1 inspected'")
 page.locator('#turn-two').click();page.locator('#send-turn').click();page.wait_for_function("()=>document.getElementById('session-status').textContent==='Turn 2 inspected'")
 assert 'Cross-turn attack detected' in page.locator('#session-latest').inner_text();checks.append('Two-turn attack trigger blocked using session context')
 page.locator('#reset-session').click();page.wait_for_function("()=>document.getElementById('session-status').textContent==='Session cleared'")
 page.locator('#send-turn').click();page.wait_for_function("()=>document.getElementById('session-status').textContent==='Turn 1 inspected'")
 assert page.locator('#session-latest').inner_text().startswith('ALLOW');checks.append('Reset clears context; isolated Proceed passes')
 page.locator('[data-view="evaluate"]').click();page.locator('#run-eval').click();page.wait_for_function("()=>!document.getElementById('export-eval').disabled")
 assert page.locator('#eval-table tr').count()==92
 page.locator('#failures-only').check();assert page.locator('#eval-table tr').count()>0
 checks.append('92 measured evaluation cases; failure filter shows real failures')
 page.screenshot(path=str(artifacts/'evaluation.png'),full_page=True)
 page.locator('#eval-table .sample').first.click();assert page.locator('#view-inspect').is_visible();checks.append('Evaluation failure replays into inspector')
 page.locator('#tool').select_option('send_email');page.locator('#guard').click();page.wait_for_function("()=>document.getElementById('tool-result').textContent.includes('allowlist')")
 assert 'false' in page.locator('#tool-result').inner_text();checks.append('Disallowed tool denied in UI')
 page.locator('[data-view="overview"]').click();page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(artifacts/'mobile.png'),full_page=True)
 assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'), 'Mobile horizontal overflow'
 checks.append('390px mobile layout has no horizontal overflow')
 browser.close()
assert not errors,errors
report={'browser':'Chromium headless','passed':len(checks),'checks':checks,'javascript_errors':errors,'live_provider_tested':False}
(artifacts/'browser-qa.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
