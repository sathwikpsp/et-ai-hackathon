# What we can detect in a PDF

A rendered screenshot and a PDF's object structure are different inputs. An image painted over a text object hides it from the viewer, but does not remove its text operators. An image covering an attachment icon does not remove the file specification, embedded-file stream or name-tree reference.

AEGIS v2.3 inspects these routes independently:

| Route | Handling | Executed fixture |
|---|---|---|
| Native text, including text underneath an image | Extract across pages; scan before agent context | `pdf-text-under-image.pdf`: blocked with content evidence |
| Instructions inside an embedded image on a page with normal text | Extract individual image resources; bounded upscaling/orientation OCR; scan recovered text | `pdf-mixed-image-text.pdf`: blocked |
| Embedded ZIP/package covered by a page image | Audit embedded-file/Filespec objects and xref; quarantine unknown payload | `pdf-package-covered-image.pdf`: quarantined structurally |
| Automatic action / JavaScript / Launch / active container | Discover objects; deny forwarding; never execute | `pdf-active-action.pdf`: quarantined |
| Bytes appended after final PDF EOF | Detect non-whitespace tail; withhold pending separate analysis | `pdf-appended-package.pdf`: quarantined |
| Text in metadata, annotations or field strings | Inspect bounded decoded auxiliary object text | Included in object audit |
| Unreadable, excessive or unsupported component | Withhold; mark incomplete, not successful content detection | Explicit structural findings |

The inspector's **Document structure and inspection coverage** shows objects visited, attachment names, structural findings and resource-image scan status. Detector evidence and whole-document forwarding disposition are separate.

## Limits that must remain explicit

This is a prompt-injection firewall plus conservative container policy, not an antivirus engine. Discovering a package does not reveal whether its binary payload is malicious. Unknown packages are quarantined instead of being trusted. Arbitrary binary streams without recognizable PDF container semantics, payloads hidden in pixel steganography, complex font/layout tricks, encrypted content and malformed parser exploits are not comprehensively classified. Vision models and OCR can miss text; visual understanding cannot prove that underlying PDF objects are safe. Hardened isolated parsing and dedicated malware scanning are needed before production.

No payload is executed, no package is launched and no network link is followed by this inspection path. A covered or hidden package is never assumed harmless merely because the displayed page looks normal.
