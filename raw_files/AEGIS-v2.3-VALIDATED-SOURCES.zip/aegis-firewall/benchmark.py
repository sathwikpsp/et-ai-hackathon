import json,time
from pathlib import Path
from pif.pipeline import inspect
from pif.parsers import parse_html
counts=dict(tp=0,fp=0,fn=0,tn=0); types={}; times=[]
for line in (Path(__file__).parent/'tests/cases/seed.jsonl').read_text().splitlines():
    c=json.loads(line); vis,hid=parse_html(c['text']) if c['format']=='html' else (c['text'],'')
    start=time.perf_counter(); v=inspect(vis,hidden=hid); times.append((time.perf_counter()-start)*1000)
    positive=v.action.value!='allow'; attack=c['label']=='attack'
    counts['tp' if positive and attack else 'fp' if positive else 'fn' if attack else 'tn']+=1
    if attack:
        entry=types.setdefault(c['type'],{'detected':0,'total':0});entry['total']+=1;entry['detected']+=int(positive)
report={**counts,'precision':counts['tp']/max(1,counts['tp']+counts['fp']),'recall':counts['tp']/max(1,counts['tp']+counts['fn']),'cases':sum(counts.values()),'mean_latency_ms':round(sum(times)/len(times),3),'by_type':types,'limitations':'Small synthetic demo fixtures; not an independent holdout or production guarantee.'}
print(json.dumps(report,indent=2))
