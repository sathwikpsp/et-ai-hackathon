# PDF parsing and quarantine

Extraction and security inspection are different operations. A PDF is not automatically quarantined.

| Observed result | Meaning | Next step |
|---|---|---|
| BLOCK with rule/decoder/hidden-content evidence | Content matched an attack detector | Read evidence; included poisoned sample should block |
| QUARANTINE with `local_ml` | Small local model found attack-like wording | Can be a false positive; inspect exact evidence and test a configured semantic judge |
| QUARANTINE with model unavailable/error | An explicitly requested model could not validate content | Read actionable reason: configure provider/key, fix quota/model, start Ollama, or disable model judgment for a local scan |
| QUARANTINE with truncated review | Judge reviewed only the first 24,000 characters | Test smaller inputs; whole original remains withheld |
| FILE WITHHELD | Extraction did not complete | Read extraction error; try Gemini PDF reading or local PyMuPDF/Tesseract for scanned pages |
| ALLOW | No configured detector crossed a threshold | Not a guarantee of safety; downstream tool allowlist still applies |

Plain text/HTML/Word and text PDFs do not require Tesseract. Images and scanned PDF pages require Tesseract only when using local extraction. Gemini model extraction reads the PDF/image directly. Ollama can read images if the installed model has vision; use local extraction for PDFs.

A no-text PDF page is rasterized for bounded local OCR. If no readable body text can be recovered, metadata alone no longer lets the document pass. There is a 100-page PDF limit and a 10-page local scanned-page OCR limit. Empty or deliberately blank pages can cause withholding; this conservative choice prevents unreadable documents from being treated as inspected.

Do not disable the firewall or mark PDFs trusted to remove quarantine. Export the verdict JSON or copy `decision_reason`, `llm`, and `evidence` to diagnose it. Remove confidential text and credentials before sharing diagnostic exports.
