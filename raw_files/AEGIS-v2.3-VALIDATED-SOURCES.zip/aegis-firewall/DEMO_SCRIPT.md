# Five-minute judge demo

## Before presenting

Run the app and verify the page loads. For a live-AI demonstration configure your own working Gemini or provider key, or local Ollama model locally, then try a clean scan with live mode checked. Keep the local mode fallback ready. Test OCR before relying on the image sample. Open the application, this script, and `artifacts/pitch-deck.pdf` in advance.

## 0:00–0:35 — Business problem

“Agents read websites, emails and documents, then use tools. Attackers can hide instructions inside that external data. AEGIS puts two enforceable boundaries between untrusted content and agent actions: one before context, another before tool execution.”

Show Overview. Point to the ingestion → firewall → protected agent flow. Describe the actual model mode shown in the header.

## 0:35–1:25 — Invisible attack, visible evidence

Click **Load hidden HTML**, then **Inspect content**. Show the innocent revenue text and the hidden instruction. The decision is BLOCK; evidence records hidden-content, source and classifier/rule signals. Show the forwarding payload: a quarantine marker, not the hostile document.

“Source attribution does not grant trust. We do not promise partial cleaning; we quarantine the whole item.”

Upload `samples/hidden-instruction.docx`. Show visible-versus-hidden extraction counts. If OCR was verified, upload `samples/injection-screenshot.png` for the visual-input demonstration.

## 1:25–2:30 — Agent planning and actual enforcement

Open **Agent sandbox**. Keep the authorized summary task and poisoned report. If configured and tested, enable live mode. Click **Run protected agent**.

Show: user-task inspection → external-content block → planner → allowlisted tool → actual local summary. The attack never reaches the planner. The trusted fallback report allows the useful task to continue. Show executed call and output.

“Live mode uses an LLM judge and LLM planner. Local mode uses our trained classifier and a deterministic planner. Every proposed call goes through the same server-side policy.”

Load the clean report and run again. It passes and the summary uses its real contents. In **Content inspector**, choose `send_email` and evaluate: denied before execution.

## 2:30–3:10 — Cross-turn attack

Open **Session defense**. Submit the staged instruction. Load turn 2, “Proceed”, and inspect. Show **Cross-turn attack detected**. Reset the session and submit “Proceed” again: it passes in isolation.

“Session context is bounded and temporary; the earlier malicious instruction never becomes authority.”

## 3:10–4:00 — Measured reliability, with limits

Open **Adversarial lab** and run the suite. Show actual precision, recall, false positives, P95 time, and case-level results. Check **Show failures only** and replay one.

“These 92 cases are developer-authored synthetic attacks, transformations, and hard benign examples. They are not an independent benchmark. We expose failures rather than hide them: quoted attack examples, multilingual content and novel paraphrases need stronger semantic coverage.”

Do not call the local P95 time end-to-end or live-LLM latency. Do not claim the result proves production reliability.

## 4:00–5:00 — Architecture and differentiation

Show **Architecture** or the PDF diagram.

“Our differentiator is preserving a useful task while preventing data from becoming authority. We combine source-aware evidence, bounded decoding, document/OCR ingestion, cross-turn signals, grounded optional LLM judgment, and a second tool gate. The demo proves local read-only execution, not fake dangerous tool calls.”

Declare **D1/F3 conservatively**: nine attack categories are implemented; multimodal ingestion is demonstrated, but independent reliability evidence is insufficient to claim D3. Higher depth requires representative held-out evaluation, hardened parser isolation, authenticated agent integrations, and stronger semantic models.

Close: “AEGIS makes the agent’s trust decision visible and enforces it before both reasoning and action.”

## Judge questions

**How is AI central?** The local trained classifier contributes quarantine decisions for paraphrased input. Live mode, when configured, uses an LLM judge for semantic signals and an LLM planner for read-only action selection. Model evidence and tool calls are inspectable.

**Does an ALLOW mean safe?** No. It means no configured detector crossed a threshold. The downstream tool boundary still restricts possible actions.

**What does SANITIZE mean?** Whole-item quarantine. We do not claim precise span removal proves the rest safe.

**What happens when the LLM fails?** Requested but unavailable, invalid, ungrounded or incomplete judge output quarantines. Planner failure executes nothing. A benign judge cannot override a rule block.

**Is the red-team loop agentic?** It autonomously generates deterministic mutations, invokes the firewall, scores, and exposes replayable cases. It is not an LLM attack-generation agent and does not self-modify production policy.

**Can you guarantee protection?** No. This is a research prototype with visible evaluation boundaries; production rollout needs independent validation and hardened integration.

## v2.3 PDF evidence demonstration

Use Inspector with Local extraction. First upload `samples/source-validation/pdf-text-under-image.pdf`: the viewer shows a harmless overlaid image, while native extraction exposes the underlying attack and the firewall blocks it. Next upload `pdf-mixed-image-text.pdf`: image resource OCR catches the attack even though the page also has ordinary text. Finally upload `pdf-package-covered-image.pdf`: no prompt injection has to be inferred; the object audit finds `hidden-package.zip` and the structural gate quarantines the workflow. Show the object/attachment findings separately from attack evidence. Never call package discovery malware classification.

For source coverage, show `SOURCE_VALIDATION.md`: 55 fixtures / 11 input formats, 54 pass and one false-positive. For the uploaded acceptance pack show `DEEP_TEST_STATUS.md`: partial and unrun cases remain explicit. Do not claim the entire 100-case acceptance oracle passed.
