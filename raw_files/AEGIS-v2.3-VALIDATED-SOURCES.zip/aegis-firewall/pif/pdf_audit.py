"""Inspect PDF object structure independently of page rendering. Never execute payloads."""
from pypdf.generic import DictionaryObject,ArrayObject,IndirectObject,TextStringObject,ByteStringObject,StreamObject
MAX_OBJECTS=10000;MAX_AUX=100000

def audit_pdf(reader):
    findings=[];aux=[];seen=set();visited=0;budget=MAX_AUX;attachment_names=[];force_quarantine=False
    def finding(kind,location,detail,withhold=False):
        nonlocal force_quarantine
        findings.append({'kind':kind,'location':location[:140],'detail':detail[:220],'withhold':withhold});force_quarantine|=withhold
    def add(value):
        nonlocal budget
        if len(value)>budget:
            finding('audit_limit','PDF objects','Auxiliary text exceeds inspection budget',True);budget=0;return
        aux.append(value);budget-=len(value)
    def walk(value,path,depth=0):
        nonlocal visited
        if depth>35:
            finding('audit_limit',path,'Object nesting exceeds 35 levels',True);return
        if isinstance(value,IndirectObject):
            key=(value.idnum,value.generation)
            if key in seen:return
            seen.add(key);visited+=1
            if visited>MAX_OBJECTS:
                finding('audit_limit',path,'Object count exceeds 10,000',True);return
            try:value=value.get_object()
            except Exception:finding('unreadable_object',path,'Cannot decode referenced object',True);return
        if isinstance(value,DictionaryObject):
            typ=str(value.get('/Type',''));sub=str(value.get('/Subtype',''));action=str(value.get('/S',''))
            if typ=='/EmbeddedFile':
                # Packages remain inert and withheld even if a viewer covers their icon.
                finding('embedded_file',path,'Embedded file/package present. Not executed; workflow withheld pending separate analysis.',True)
            if typ=='/Filespec':
                name=str(value.get('/UF',value.get('/F','unnamed')));attachment_names.append(name);add('Attachment name: '+name)
            if action in ('/JavaScript','/Launch','/SubmitForm','/ImportData','/GoToR','/Rendition'):
                finding('active_action',path,'Active/external action '+action+' is disallowed',True)
            for key in ('/JS','/XFA','/RichMediaContent','/RichMediaSettings','/Collection'):
                if key in value:finding('active_or_unhandled_container',path+'/'+key,key+' requires isolated analysis; not forwarded',True)
            if '/OpenAction' in value or '/AA' in value:
                finding('automatic_action',path,'Automatic document/page action present',True)
            if sub in ('/FileAttachment','/RichMedia','/Movie','/Sound','/3D'):
                finding('annotation_payload',path,'Embedded/active annotation '+sub,True)
            if '/OCProperties' in value:finding('optional_content_layers',path,'Optional/hidden layers exist; object text is inspected independently')
            if typ=='/Metadata' and isinstance(value,StreamObject):
                try:
                    data=value.get_data()
                    if len(data)>MAX_AUX:finding('metadata_limit',path,'Metadata exceeds audit budget',True)
                    else:add(data.decode('utf-8',errors='replace'))
                except Exception:finding('unreadable_metadata',path,'Metadata stream could not be read',True)
            for key,item in value.items():
                if str(key) not in ('/Parent','/Prev'):walk(item,path+'/'+str(key).lstrip('/'),depth+1)
        elif isinstance(value,ArrayObject):
            if len(value)>MAX_OBJECTS:finding('audit_limit',path,'Array exceeds object budget',True);return
            for i,item in enumerate(value):walk(item,path+f'[{i}]',depth+1)
        elif isinstance(value,(TextStringObject,ByteStringObject)):
            text=str(value) if isinstance(value,TextStringObject) else bytes(value).decode('utf-8',errors='replace')
            if text.strip():add(text)
    walk(reader.trailer,'trailer')
    # Include orphaned/covered objects that are not reachable through rendered page content.
    for generation,objects in reader.xref.items():
        if generation==65535:continue
        for identifier in objects:
            if identifier:walk(IndirectObject(identifier,generation,reader),f'xref:{identifier}:{generation}')
            if visited>MAX_OBJECTS:break
        if visited>MAX_OBJECTS:break
    for identifier in reader.xref_objStm:
        walk(IndirectObject(identifier,0,reader),f'object_stream:{identifier}')
        if visited>MAX_OBJECTS:break
    try:
        position=reader.stream.tell();reader.stream.seek(0,2);length=reader.stream.tell();reader.stream.seek(max(0,length-65536));tail=reader.stream.read();reader.stream.seek(position)
        marker=tail.rfind(b'%%EOF')
        if marker<0 or tail[marker+5:].strip(b' \r\n\t\x00'):
            finding('trailing_or_missing_eof','file trailer','Non-whitespace data after final EOF, or missing EOF. Possible appended package; withheld, not executed.',True)
    except Exception:finding('trailer_audit_failed','file trailer','Cannot inspect trailing bytes',True)
    return '\n'.join(aux),{'objects_inspected':visited,'findings':findings[:100],'attachment_names':sorted(set(attachment_names)),'force_quarantine':force_quarantine,'scope':'Decoded page text + bounded PDF object graph/xref audit. No malware execution or arbitrary binary/steganography inspection.'}
