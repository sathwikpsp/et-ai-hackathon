"""Bounded local or explicitly selected model extraction; no embedded code runs."""
import base64,binascii,io,subprocess,tempfile
from pathlib import Path
from .parsers import parse_html,parse_docx
MAX_BYTES=5_000_000
EXTENSIONS={'.txt':'user','.md':'web','.html':'web','.htm':'web','.eml':'email','.json':'api','.py':'code','.js':'code','.csv':'api','.pdf':'pdf','.docx':'docx','.png':'ocr','.jpg':'ocr','.jpeg':'ocr','.webp':'ocr'}
MIMES={'.pdf':'application/pdf','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'}

def ocr(path):
    """Bounded upscaling + orientation passes. OCR is a lossy detector input."""
    from PIL import Image
    import csv
    from .rules import run_rules
    candidates=[]
    with tempfile.TemporaryDirectory(prefix='pif-ocr-') as work:
        with Image.open(path) as original:
            image=original.convert('RGB')
            if image.width*image.height>20_000_000:raise ValueError('OCR image exceeds pixel budget')
            scale=min(2.5,2000/max(image.width,image.height))
            if scale>1:image=image.resize((round(image.width*scale),round(image.height*scale)),Image.Resampling.LANCZOS)
            for angle in (0,90,270):
                candidate=image if not angle else image.rotate(angle,expand=True)
                temp=Path(work)/f'pass-{angle}.png';candidate.save(temp)
                try:
                    result=subprocess.run(['tesseract',str(temp),'stdout','--psm','6','tsv'],capture_output=True,timeout=12,check=True)
                    rows=list(csv.DictReader(io.StringIO(result.stdout.decode('utf-8')),delimiter='\t'))
                    words=[r.get('text','').strip() for r in rows if r.get('text','').strip() and float(r.get('conf','-1'))>=35]
                    text=' '.join(words)
                    # Keep baseline text; add alternate orientation only for an actual detector signal.
                    if not angle or run_rules(text):candidates.append(text)
                except FileNotFoundError:raise ValueError('Tesseract is needed only for local image/scanned-page OCR. Choose Gemini, or install Tesseract.') from None
                except (subprocess.TimeoutExpired,subprocess.CalledProcessError):raise ValueError('Local OCR failed or timed out; file not forwarded') from None
    return '\n'.join(candidates)

def extract_upload(filename,content,extraction='local'):
    if not isinstance(filename,str) or not isinstance(content,str):raise ValueError('Expected filename and base64 content')
    if extraction not in ('local','model'):raise ValueError('Choose local or model extraction')
    suffix=Path(filename).suffix.lower()
    if suffix not in EXTENSIONS:raise ValueError('Unsupported file type; use text, HTML, PDF, DOCX or an image')
    if len(content)>6_700_000:raise ValueError('File exceeds 5 MB')
    try:raw=base64.b64decode(content,validate=True)
    except (ValueError,binascii.Error):raise ValueError('Invalid base64 file') from None
    if not raw or len(raw)>MAX_BYTES:raise ValueError('File is empty or exceeds 5 MB')
    warnings=[];method='UTF-8 text';pages=None;hidden='';recovered=[];scanned=[];model_info=None;structure=None;image_results=[];mime_report=None
    with tempfile.TemporaryDirectory(prefix='pif-') as directory:
        path=Path(directory)/('input'+suffix);path.write_bytes(raw)
        if suffix=='.pdf':
            from pypdf import PdfReader
            reader=PdfReader(io.BytesIO(raw))
            if reader.is_encrypted:raise ValueError('Encrypted PDF cannot be inspected')
            if len(reader.pages)>100:raise ValueError('PDF exceeds 100 pages')
            from .pdf_audit import audit_pdf
            audit_text,structure=audit_pdf(reader)
            pages=len(reader.pages);parts=[page.extract_text() or '' for page in reader.pages];hidden=str(reader.metadata or '')+'\n'+audit_text
            scanned=[i for i,text in enumerate(parts) if not text.strip()]
            if extraction=='model':
                from .vision import transcribe
                recovered_text,model_info,model_warnings=transcribe(raw,'application/pdf')
                # Model cannot erase instructions recovered by deterministic text extraction.
                text='\n'.join(parts)+'\n'+recovered_text;method=model_info['provider']+' direct PDF reading + pypdf text/metadata';warnings+=model_warnings
            else:
                if scanned:
                    if len(scanned)>10:raise ValueError('More than 10 PDF pages have no extracted text; choose Gemini model extraction')
                    try:import pymupdf
                    except ImportError:raise ValueError('Scanned PDF requires PyMuPDF + Tesseract locally, or choose Gemini model extraction') from None
                    with pymupdf.open(path) as doc:
                        for i in scanned:
                            page=doc.load_page(i)
                            if page.rect.width*page.rect.height*1.6**2>20_000_000:raise ValueError('Rendered PDF page exceeds pixel limit')
                            png=Path(directory)/f'page-{i}.png';page.get_pixmap(matrix=pymupdf.Matrix(1.6,1.6),alpha=False).save(png)
                            parts[i]=ocr(png)
                            if not parts[i].strip():raise ValueError(f'PDF page {i+1} has no recoverable text. File withheld; try model extraction.')
                            recovered.append(i+1)
                text='\n'.join(parts);method='PDF text + metadata'+(' + scanned-page Tesseract OCR' if recovered else '')
            # Resource images are inspected individually, including images covered by other objects.
            image_seen=set();image_count=0
            for page_index,page in enumerate(reader.pages):
                try:images=list(page.images)
                except Exception:
                    structure['force_quarantine']=True;structure['findings'].append({'kind':'unreadable_images','location':f'page {page_index+1}','detail':'Cannot enumerate image resources','withhold':True});continue
                for image_index,item in enumerate(images):
                    import hashlib
                    digest=hashlib.sha256(item.data).hexdigest()
                    if digest in image_seen:continue
                    image_seen.add(digest);image_count+=1
                    if image_count>40:
                        structure['force_quarantine']=True;structure['findings'].append({'kind':'image_budget','location':f'page {page_index+1}','detail':'More than 40 distinct images; remaining images unscanned','withhold':True});break
                    try:
                        im=item.image
                        if im.width*im.height>20_000_000:raise ValueError('Embedded image exceeds pixel budget')
                        image_path=Path(directory)/f'image-{page_index}-{image_index}.png';im.convert('RGB').save(image_path)
                        if extraction=='model':
                            from .vision import transcribe
                            image_text,_,_=transcribe(image_path.read_bytes(),'image/png')
                        else:image_text=ocr(image_path)
                        if image_text.strip():hidden+='\n[PDF image page '+str(page_index+1)+']\n'+image_text
                        image_results.append({'page':page_index+1,'image':image_index+1,'characters':len(image_text),'status':'inspected'})
                    except Exception as e:
                        structure['force_quarantine']=True;structure['findings'].append({'kind':'unscanned_image','location':f'page {page_index+1} image {image_index+1}','detail':str(e)[:180],'withhold':True})
                        image_results.append({'page':page_index+1,'image':image_index+1,'status':'withheld'})
            method+=' + object/attachment audit + resource-image scan'
            warnings+=['PDF objects and resource images are scanned independently of rendering. Unknown embedded files, active content and incomplete scans quarantine the workflow. Binary malware and steganography are not classified.']
        elif suffix=='.docx':
            import zipfile
            text,hidden=parse_docx(path);method='DOCX runs + hidden runs/comments'
            with zipfile.ZipFile(path) as package:
                opaque=[name for name in package.namelist() if name.startswith('word/embeddings/') or 'vbaProject' in name]
            if opaque:structure={'force_quarantine':True,'findings':[{'kind':'embedded_package','location':name,'detail':'Embedded or macro payload is not executed; requires separate analysis','withhold':True} for name in opaque]}
        elif suffix in ('.png','.jpg','.jpeg','.webp'):
            from PIL import Image
            try:
                with Image.open(path) as image:
                    if image.width*image.height>20_000_000:raise ValueError('Image exceeds 20 million pixels')
                    image.convert('RGB').save(Path(directory)/'ocr.png')
            except OSError:raise ValueError('Invalid or unreadable image') from None
            if extraction=='model':
                from .vision import transcribe
                text,model_info,model_warnings=transcribe(raw,MIMES[suffix]);method=model_info['provider']+' vision transcription';warnings+=model_warnings
            else:text=ocr(Path(directory)/'ocr.png');method='Tesseract OCR'
            warnings+=['Vision/OCR can miss small, hidden, rotated or low-contrast instructions. Model extraction is not pixel-grounded proof.']
        elif suffix=='.eml':
            from .email_parser import parse_email
            text,hidden,mime_report=parse_email(raw,extraction)
            method='MIME headers + all text/HTML parts + bounded attachment inspection'
        else:
            try:text=raw.decode('utf-8-sig')
            except UnicodeError:raise ValueError('Text file must use UTF-8') from None
            text,hidden=parse_html(text) if suffix in ('.html','.htm') else (text,'')
    if not text.strip():raise ValueError('No readable body text was recovered; file not forwarded. Use Gemini for scanned PDFs/images.')
    if len(text)+len(hidden)>200_000:raise ValueError('Extracted content exceeds 200,000 characters')
    return text,hidden,EXTENSIONS[suffix],{'filename':Path(filename).name,'bytes':len(raw),'characters':len(text),'hidden_characters':len(hidden),'method':method,'pages':pages,'ocr_pages':recovered,'warnings':warnings,'model':model_info['model'] if model_info else None,'processing':'local' if not model_info or model_info['provider']=='ollama' else model_info['provider'],'pdf_structure':structure if suffix=='.pdf' else None,'docx_structure':structure if suffix=='.docx' else None,'resource_images':image_results,'mime':mime_report,'force_quarantine':bool((structure and structure['force_quarantine']) or (mime_report and mime_report['force_quarantine']))}
