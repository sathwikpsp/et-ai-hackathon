"""Bounded, ephemeral session analysis. Client IDs are not authenticated identities."""
import re,time
from collections import OrderedDict
from threading import Lock
from .pipeline import inspect
from .schema import Evidence, AttackType, Action
_SESSIONS=OrderedDict(); _LOCK=Lock(); TTL=1800

def session_inspect(text,source,hidden,session_id,use_llm=False):
    if not isinstance(session_id,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,64}',session_id): raise ValueError('Session ID must be 1–64 letters, numbers, underscores or hyphens')
    with _LOCK:
        now=time.monotonic()
        for key in list(_SESSIONS):
            if now-_SESSIONS[key]['updated']>TTL: del _SESSIONS[key]
        state=_SESSIONS.setdefault(session_id,{'turns':[],'updated':now})
        previous=list(state['turns']); state['updated']=now; _SESSIONS.move_to_end(session_id)
        state['turns']=(previous+[text[:12000]])[-6:]
        while len(_SESSIONS)>100: _SESSIONS.popitem(last=False)
    verdict=inspect(text,source,hidden,use_llm)
    combined='\n'.join(previous+[text[:12000]])
    # A reference to earlier exfiltration instructions can be harmless in isolation.
    planning=bool(re.search(r'(?i)(?:next (?:message|turn)|later|when i say|step 1|in two steps)', '\n'.join(previous)))
    executing=bool(re.search(r'(?i)\b(?:proceed|continue|do it|send it|execute|step 2|now transmit)\b',text))
    if previous and planning and executing:
        context=inspect(combined,source)
        if context.action!=Action.ALLOW:
            verdict.evidence.append(Evidence(detector='session_context',attack_type=AttackType.MULTI_STEP_JAILBREAK,span='Earlier staged instruction + current execution trigger',score=.9))
            verdict.risk=max(verdict.risk,.9); verdict.action=Action.BLOCK
            verdict.sanitized_text='[Untrusted content quarantined by Prompt Injection Firewall]'
            verdict.attack_types=sorted(set(verdict.attack_types+[AttackType.MULTI_STEP_JAILBREAK]),key=lambda t:t.value)
            verdict.trace[-1]={'stage':'Enforce trust boundary','status':'block','detail':'Cross-turn escalation detected; content quarantined'}
    verdict.session={'id':session_id,'turns_considered':len(previous)+1,'retention':'Ephemeral; at most six prior messages, 30 minute TTL', 'cross_turn_detected':any(e.detector=='session_context' for e in verdict.evidence)}
    return verdict

def reset_session(session_id):
    with _LOCK: _SESSIONS.pop(session_id,None)
