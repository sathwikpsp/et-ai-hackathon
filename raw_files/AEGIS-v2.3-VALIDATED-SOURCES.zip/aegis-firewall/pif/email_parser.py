"""Inspect all MIME alternatives and attachments; never display only one and trust the rest."""
import base64
from email.parser import BytesParser
from email import policy
from .parsers import parse_html

def parse_email(raw,extraction='local'):
    message=BytesParser(policy=policy.default).parsebytes(raw);visible=[];hidden=[];records=[];force=False
    hidden.extend(str(key)+': '+str(value) for key,value in message.items())
    for i,part in enumerate(message.walk()):
        if i>50:force=True;records.append({'status':'withheld','reason':'MIME part budget exceeded'});break
        if part.is_multipart():continue
        payload=part.get_payload(decode=True) or b'';kind=part.get_content_type();filename=part.get_filename()
        if len(payload)>5_000_000:force=True;records.append({'status':'withheld','reason':'MIME part exceeds size limit'});continue
        if filename or part.get_content_disposition()=='attachment' or kind not in ('text/plain','text/html'):
            filename=filename or ('attachment.pdf' if kind=='application/pdf' else 'attachment.bin')
            if filename.lower().endswith(('.eml','.msg')):
                force=True;records.append({'filename':filename,'status':'withheld','reason':'Nested message attachment requires separate inspection'});continue
            try:
                from .uploads import extract_upload
                text,aux,source,report=extract_upload(filename,base64.b64encode(payload).decode(),extraction)
                hidden.append('[Email attachment '+filename+']\n'+text+'\n'+aux)
                force|=report.get('force_quarantine',False);records.append({'filename':filename,'status':'inspected','source':source,'method':report['method']})
            except Exception as e:force=True;records.append({'filename':filename,'status':'withheld','reason':str(e)[:160]})
        else:
            try:text=payload.decode(part.get_content_charset() or 'utf-8',errors='strict')
            except (UnicodeError,LookupError):force=True;records.append({'status':'withheld','reason':'Undecodable MIME text part'});continue
            text,aux=parse_html(text) if kind=='text/html' else (text,'')
            visible.append(text);hidden.append(aux);records.append({'type':kind,'status':'inspected','characters':len(text)})
    return '\n'.join(visible),'\n'.join(hidden),{'parts':records,'force_quarantine':force}
