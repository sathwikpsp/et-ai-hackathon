"""Bounded normalization of explicit encoding layers; decoding is not execution."""
import base64,re,unicodedata,codecs,json,html
from urllib.parse import unquote
ZERO_WIDTH=dict.fromkeys(map(ord,'\u200b\u200c\u200d\u2060\ufeff\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069'),None)
B64=re.compile(r'[A-Za-z0-9+/]{24,}={0,2}')
def strip_invisible(text):
    text=unicodedata.normalize('NFKC',text).translate(ZERO_WIDTH)
    # Target common OCR substitutions only in known instruction-bearing words.
    for pattern,replacement in [(r'\br[e3]vea[l1]\b','reveal'),(r'\bpr[i1]vat[e3]\b','private'),(r'\bc[o0]nt[e3]xt\b','context'),(r'\bs[e3]cr[e3]t(s?)\b',r'secret\1')]:
        text=re.sub(pattern,replacement,text,flags=re.I)
    return text
def decode_layers(text,depth=2):
    segments=[]; seen=set(); pending=[text]; budget=200_000
    for _ in range(min(max(depth,0),3)):
        next_layer=[]
        for item in pending:
            candidates=[]
            unescaped=html.unescape(item)
            if unescaped!=item:candidates.append(unescaped)
            if item.lstrip().startswith(('{','[')):
                try:
                    obj=json.loads(item); pending_values=[obj];strings=[]
                    while pending_values and len(strings)<1000:
                        val=pending_values.pop()
                        if isinstance(val,str):strings.append(val)
                        elif isinstance(val,dict):pending_values.extend(list(val.values())[:1000])
                        elif isinstance(val,list):pending_values.extend(val[:1000])
                    if strings:candidates.append('\n'.join(strings))
                except (ValueError,RecursionError):pass
            for match in re.finditer(r'(?i)(?<![a-z0-9])[0-9a-f]{48,}(?![a-z0-9])',item):
                try:candidates.append(bytes.fromhex(match.group()).decode('utf-8'))
                except (ValueError,UnicodeError):pass
            for match in list(B64.finditer(item))[:64]:
                try: candidates.append(base64.b64decode(match.group(),validate=True).decode('utf-8'))
                except (ValueError,UnicodeError): pass
            if re.search(r'%[0-9a-fA-F]{2}',item): candidates.append(unquote(item))
            for match in re.finditer(r'(?i)hex\s*:\s*([0-9a-f]{24,})',item):
                try: candidates.append(bytes.fromhex(match[1]).decode('utf-8'))
                except (ValueError,UnicodeError): pass
            for match in re.finditer(r'(?i)rot13\s*:\s*([^\n]{1,4000})',item): candidates.append(codecs.decode(match[1],'rot_13'))
            for decoded in candidates:
                decoded=strip_invisible(decoded)
                if decoded in seen or decoded==item or not decoded or len(decoded)>budget or not all(c.isprintable() or c in '\n\r\t' for c in decoded): continue
                seen.add(decoded); budget-=len(decoded); segments.append(decoded); next_layer.append(decoded)
        pending=next_layer
        if not pending: break
    return text+'\n'+'\n'.join(segments),segments
def normalize(text): return decode_layers(strip_invisible(text))

def has_unreviewed_encoding(text,decoded):
    known=set(decoded)
    for item in [text]+decoded:
        for match in list(B64.finditer(item))[:64]:
            try:value=base64.b64decode(match.group(),validate=True).decode('utf-8')
            except (ValueError,UnicodeError):continue
            value=strip_invisible(value)
            if value and all(c.isprintable() or c in '\n\r\t' for c in value) and value not in known:return True
    return False
