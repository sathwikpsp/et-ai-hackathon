"""Extract visible and hidden content without executing document code."""
from html.parser import HTMLParser
from pathlib import Path
import zipfile
import xml.etree.ElementTree as ET

class Extractor(HTMLParser):
    def __init__(self):
        super().__init__(); self.visible=[]; self.hidden=[]; self.stack=[]
    def handle_starttag(self, tag, attrs):
        a=dict(attrs); style=a.get('style','').replace(' ','').lower()
        hidden=tag in ('script','style') or 'hidden' in a or a.get('aria-hidden')=='true' or any(x in style for x in ('display:none','visibility:hidden','font-size:0'))
        # Attribute text can also carry instructions unseen in the rendered body.
        for key,value in attrs:
            if value and (key in ('alt','title','aria-label') or key.startswith('data-')):
                self.hidden.append(value)
        if tag not in ('br','img','meta','link','input','hr'): self.stack.append((tag,hidden))
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,-1,-1):
            if self.stack[i][0]==tag: del self.stack[i:]; break
    def handle_data(self,data):
        (self.hidden if any(h for _,h in self.stack) else self.visible).append(data)
    def handle_comment(self,data): self.hidden.append(data)

def parse_text(raw): return raw,''
def parse_html(raw):
    parser=Extractor(); parser.feed(raw)
    return ' '.join(parser.visible),' '.join(parser.hidden)

def parse_pdf(path):
    from pypdf import PdfReader
    reader=PdfReader(path)
    return '\n'.join(page.extract_text() or '' for page in reader.pages),str(reader.metadata or '')

def parse_docx(path):
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    visible=[]; hidden=[]
    with zipfile.ZipFile(path) as z:
        if sum(i.file_size for i in z.infolist()) > 20_000_000: raise ValueError('Expanded document exceeds 20 MB')
        for name in z.namelist():
            if not name.startswith('word/') or not name.endswith('.xml'): continue
            root=ET.fromstring(z.read(name))
            for run in root.findall('.//w:r',ns):
                text=''.join(t.text or '' for t in run.findall('.//w:t',ns))
                is_hidden=run.find('.//w:vanish',ns) is not None or 'comments' in name
                (hidden if is_hidden else visible).append(text)
    return ' '.join(visible),' '.join(hidden)

def parse_image(path):
    import pytesseract
    from PIL import Image
    with Image.open(path) as im:
        if im.width*im.height>20_000_000: raise ValueError('Image exceeds 20 million pixels')
        return pytesseract.image_to_string(im),''
