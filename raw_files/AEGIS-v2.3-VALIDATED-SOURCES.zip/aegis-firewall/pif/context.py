"""Distinguish explicitly requested user analysis of quoted examples from directives.
This never grants trust or tool permissions, and does not exempt unquoted instructions.
"""
import re
EDUCATIONAL=re.compile(r'^(?:Explain why|Analyze this quoted email|Review a unit test string|Our rule detects|In the incident report)\b',re.I)
QUOTES=re.compile(r'"[^"\n]*"|“[^”\n]*”|`[^`\n]*`')
def detection_view(text,source):
    if source=='user' and EDUCATIONAL.search(text.strip()) and QUOTES.search(text):
        return QUOTES.sub(' [quoted analysis example] ',text),True
    return text,False
