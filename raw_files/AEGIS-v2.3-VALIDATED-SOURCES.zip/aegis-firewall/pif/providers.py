"""JSON-only inference adapters. Fixed cloud endpoints or fixed local Ollama only."""
import json,os,re,urllib.request,urllib.error,socket
DEFAULTS={'openai':'gpt-4.1-mini','gemini':'gemini-3.8-flash','ollama':'gemma3:4b'}
PROVIDER=os.environ.get('PIF_PROVIDER','openai').lower()
MODEL=os.environ.get('PIF_MODEL',DEFAULTS.get(PROVIDER,DEFAULTS['openai']))
LOCAL_ENABLED=os.environ.get('PIF_PROVIDER')=='ollama'

def status():
    ready=LOCAL_ENABLED if PROVIDER=='ollama' else bool(os.environ.get('GEMINI_API_KEY' if PROVIDER=='gemini' else 'OPENAI_API_KEY'))
    return {'configured':ready,'model':MODEL,'provider':PROVIDER,'external_processing':'Local Ollama inference' if PROVIDER=='ollama' else f'Opt-in requests send content to {PROVIDER}', 'vision_available':PROVIDER in ('gemini','ollama')}

def configure(provider,model,key=None):
    global PROVIDER,MODEL,LOCAL_ENABLED
    if provider not in DEFAULTS: raise ValueError('Choose openai, gemini or ollama')
    model=model or DEFAULTS[provider]
    if not isinstance(model,str) or not re.fullmatch(r'[a-zA-Z0-9._:-]{1,100}',model): raise ValueError('Invalid model name')
    if provider!='ollama':
        env='GEMINI_API_KEY' if provider=='gemini' else 'OPENAI_API_KEY'
        if key:
            if not isinstance(key,str) or not 20<=len(key)<=500 or any(c.isspace() for c in key): raise ValueError('Enter a valid API key')
            os.environ[env]=key
        elif not os.environ.get(env): raise ValueError('Enter an API key for this provider')
    PROVIDER=provider;MODEL=model;LOCAL_ENABLED=provider=='ollama'
    return status()

def _output(obj):
    if isinstance(obj.get('output_text'),str): return obj['output_text']
    texts=[]
    for item in obj.get('outputs',obj.get('output',[])):
        if isinstance(item,dict) and item.get('type')=='text' and isinstance(item.get('text'),str): texts.append(item['text'])
    if not texts: raise ValueError('Provider returned no text output')
    return ''.join(texts)

def complete_json(system,user,schema=None,media=None):
    cfg=status()
    if not cfg['configured']: raise ValueError(f'{PROVIDER} is not configured. Connect the provider in Overview.')
    headers={'Content-Type':'application/json'}
    if PROVIDER=='openai':
        if media: raise ValueError('Choose Gemini or a vision-capable Ollama model for visual extraction')
        url='https://api.openai.com/v1/chat/completions';headers['Authorization']='Bearer '+os.environ['OPENAI_API_KEY']
        payload={'model':MODEL,'temperature':0,'max_tokens':1800,'response_format':{'type':'json_object'},'messages':[{'role':'system','content':system},{'role':'user','content':user}]}
    elif PROVIDER=='gemini':
        url='https://generativelanguage.googleapis.com/v1beta/interactions';headers['x-goog-api-key']=os.environ['GEMINI_API_KEY']
        content=[{'type':'text','text':user}]
        if media:content.append({'type':'document' if media['mime_type']=='application/pdf' else 'image','data':media['data'],'mime_type':media['mime_type']})
        payload={'model':MODEL,'system_instruction':system,'input':content,'store':False,'response_format':{'type':'text','mime_type':'application/json'}}
        if schema:payload['response_format']['schema']=schema
    else:
        if media and media['mime_type']=='application/pdf':raise ValueError('Ollama image extraction accepts images only; PDFs use local text/OCR extraction')
        url='http://127.0.0.1:11434/api/generate'
        payload={'model':MODEL,'system':system,'prompt':user,'format':schema or 'json','stream':False,'options':{'temperature':0,'num_predict':4096}}
        if media:payload['images']=[media['data']]
    request=urllib.request.Request(url,data=json.dumps(payload).encode(),headers=headers)
    try:
        # Explicitly local Ollama bypasses HTTP proxies; cloud requests keep session proxies.
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({})) if PROVIDER=='ollama' else urllib.request.build_opener()
        # urlopen retained for cloud adapters so provider validation tests can mock the boundary.
        with (opener.open(request,timeout=60) if PROVIDER=='ollama' else urllib.request.urlopen(request,timeout=45)) as response:
            raw=response.read(2_000_001)
        if len(raw)>2_000_000: raise ValueError('Provider output exceeded limit')
        result=json.loads(raw)
        output=result['choices'][0]['message']['content'] if PROVIDER=='openai' else result['response'] if PROVIDER=='ollama' else _output(result)
        obj=json.loads(output)
        if not isinstance(obj,dict):raise ValueError('Model must return a JSON object')
        return obj
    except urllib.error.HTTPError as e:
        reason={400:'Unsupported model or request format',401:'API key rejected',403:'Key lacks access to this model',404:'Model or endpoint not found',429:'Provider quota or rate limit exceeded'}.get(e.code,'Provider server error')
        raise ValueError(f'{PROVIDER}: {reason} (HTTP {e.code}).') from None
    except (TimeoutError,socket.timeout):raise ValueError(f'{PROVIDER}: request timed out; content withheld.') from None
    except urllib.error.URLError:raise ValueError('Ollama is not reachable at 127.0.0.1:11434; start Ollama and pull the chosen model.' if PROVIDER=='ollama' else f'{PROVIDER}: network connection failed.') from None
    except (KeyError,TypeError,json.JSONDecodeError):raise ValueError(f'{PROVIDER}: invalid JSON response or missing output.') from None
