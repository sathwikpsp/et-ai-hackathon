"""Shared whole-document enforcement for HTTP and programmatic ingestion."""
from .pipeline import inspect
from .schema import Action

def enforce_structure(verdict,extraction):
    verdict.extraction=extraction
    if extraction and extraction.get('force_quarantine'):
        if verdict.action==Action.ALLOW:verdict.action=Action.SANITIZE;verdict.risk=max(.4,verdict.risk)
        verdict.sanitized_text='[Document quarantined: embedded/active content or incomplete structural inspection]'
        # Preserve detected injection evidence while distinguishing container rejection.
        verdict.decision_reason=('Content detector: '+verdict.decision_reason+'; ' if verdict.evidence else '')+'Structural safety policy: embedded package, active content, or unscanned component. Container rejection is not itself confirmed prompt injection.'
        verdict.trace.append({'stage':'Document structural gate','status':verdict.action.value,'detail':verdict.decision_reason})
    return verdict

def inspect_upload(filename,content,extraction='local',use_llm=False):
    from .uploads import extract_upload
    text,hidden,source,report=extract_upload(filename,content,extraction)
    return enforce_structure(inspect(text,source,hidden,use_llm),report)
