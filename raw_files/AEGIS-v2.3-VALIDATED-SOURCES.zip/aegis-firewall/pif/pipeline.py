import time
from .schema import Verdict, Evidence, Action, AttackType
from .normalizer import normalize, has_unreviewed_encoding
from .rules import run_rules
from .semantic import classifier_score, predict, TRAINING
from .llm import judge
from .context import detection_view
BLOCK_AT, SANITIZE_AT = 0.75, 0.4

def llm_judge(text):
    return judge(text,'user')[0]

def inspect(text: str, source: str = 'user', hidden: str = '', use_llm=False) -> Verdict:
    if not isinstance(text,str) or not isinstance(hidden,str): raise ValueError('Content must be text')
    if len(text)+len(hidden)>200_000: raise ValueError('Content exceeds 200,000 characters')
    start=time.perf_counter(); detection_text,quoted_analysis=detection_view(text,source); expanded,decoded=normalize(detection_text); ev=[]
    for t,span,s in run_rules(expanded): ev.append(Evidence(detector='rules',attack_type=t,span=span,score=s))
    for seg in decoded:
        for t,span,s in run_rules(seg): ev.append(Evidence(detector='decoder',attack_type=AttackType.ENCODED_INSTRUCTION,span=span,score=min(1,s+.1)))
    if hidden:
        h,hdecoded=normalize(hidden)
        findings=run_rules(h)+classifier_score(h)
        for t,span,s in findings: ev.append(Evidence(detector='hidden_content',attack_type=AttackType.INDIRECT_INJECTION,span=span,score=max(.8,s)))
        for seg in hdecoded:
            for t,span,s in run_rules(seg): ev.append(Evidence(detector='decoder',attack_type=AttackType.ENCODED_INSTRUCTION,span=span,score=.9))
    for t,span,s in classifier_score(expanded): ev.append(Evidence(detector='local_ml',attack_type=t,span=span,score=s))
    if source not in ('user','tool_arguments') and ev:
        strongest=max(ev,key=lambda x:x.score)
        ev.append(Evidence(detector='source_boundary',attack_type=AttackType.INDIRECT_INJECTION,span=strongest.span,score=strongest.score))
    llm={'state':'not_requested'}
    if use_llm:
        extra,llm=judge((normalize(text)[0] if quoted_analysis else expanded)+'\n'+hidden,source); ev.extend(extra)
    unresolved=has_unreviewed_encoding(detection_text,decoded)
    risk=max((e.score for e in ev),default=0)
    action=Action.BLOCK if risk>=BLOCK_AT else Action.SANITIZE if risk>=SANITIZE_AT else Action.ALLOW
    if use_llm and (llm['state']!='completed' or llm.get('truncated')) and action==Action.ALLOW:
        action=Action.SANITIZE; risk=max(risk,.4)
    if unresolved and action==Action.ALLOW:action=Action.SANITIZE;risk=max(.4,risk)
    safe=text if action==Action.ALLOW else '[Untrusted content quarantined by Prompt Injection Firewall]'
    if action==Action.ALLOW: reason='No configured detector crossed a threshold. This is not proof of safety.'
    elif use_llm and llm['state']!='completed' and not ev: reason='Requested model could not validate the content: '+llm.get('detail','unavailable')
    elif use_llm and llm.get('truncated') and not ev: reason='Model reviewed only the first 24,000 characters; unreviewed content quarantined.'
    elif unresolved and not ev:reason='Encoding depth/budget limit left an unreviewed textual payload; whole item quarantined, not classified as a confirmed attack.'
    elif ev:
        strongest=max(ev,key=lambda e:e.score)
        reason=f'{strongest.detector} flagged {strongest.attack_type.value}: {strongest.span[:150]}'
        if strongest.detector=='local_ml':reason+=' Small uncalibrated classifier; this may be a false positive.'
    else:reason='Content quarantined because inspection could not establish a complete result.'
    elapsed=round((time.perf_counter()-start)*1000,2)
    return Verdict(action=action,risk=risk,attack_types=sorted({e.attack_type for e in ev},key=lambda t:t.value),evidence=ev,source=source,trusted=False,sanitized_text=safe,decision_reason=reason,llm=llm,latency_ms=elapsed,trace=[{'stage':'Normalize & decode','status':'complete','detail':f'{len(decoded)} decoded layers; Unicode normalization'}, {'stage':'Policy & hidden-content scan','status':'complete','detail':f'{len(ev)} evidence signals; {len(hidden)} hidden characters'}, {'stage':'Local ML classifier','status':'complete','detail':f'Trainable character-ngram Naive Bayes · {len(TRAINING)} demo examples · signal {predict(expanded):.3f} (uncalibrated)'}, {'stage':'LLM adjudicator','status':llm['state'],'detail':llm.get('reason',llm.get('detail','Optional external model not requested'))}, {'stage':'Enforce trust boundary','status':action.value,'detail':reason}])
