"""Fast first-stage rules. Starter patterns only; the classifier and LLM judge handle paraphrases."""
import re
from .schema import AttackType as A

RULES = [
    (A.INSTRUCTION_OVERRIDE, r"\b(ignore|disregard|forget)\b.{0,30}\b(previous|prior|above|earlier)\b.{0,20}\b(instructions?|rules?|prompt)"),
    (A.ROLE_CHANGE, r"\b(you are now|pretend to be|from now on you)\b"),
    (A.SECRET_EXTRACTION, r"\b(reveal|print|show|repeat)\b.{0,30}\b(system prompt|hidden instructions?|your instructions)"),
    (A.CREDENTIAL_THEFT, r"\b(api[_ -]?key|password|token|credentials?|secret)\b.{0,40}\b(send|email|post|forward|upload)\b|\b(send|email|post|forward|upload)\b.{0,40}\b(api[_ -]?key|password|token|credentials?)\b"),
    (A.TOOL_ABUSE, r"\b(call|use|invoke|run)\b.{0,25}\b(tool|function|command|shell)\b.{0,40}\b(delete|send|transfer|exfiltrate|download)\b"),
]
COMPILED = [(t, re.compile(p, re.I | re.S)) for t, p in RULES]

def run_rules(text: str):
    out = []
    for t, rx in COMPILED:
        cursor=0
        while True:
            m=rx.search(text,cursor)
            if not m: break
            cursor=m.start()+1
            prefix=text[max(0,m.start()-28):m.start()]
            # Scope simple explicit negation to the matched directive, not the whole item.
            if re.search(r'(?:never|do not|must not|don.t)\s*$',prefix,re.I):
                continue
            out.append((t, m.group(0)[:120], 0.8))
            break
    return out

COMPILED += [(t,re.compile(pattern,re.I|re.S)) for t,pattern in [
 (A.CONTEXT_POISONING, r"(?:replace|overwrite|treat).{0,45}(?:verified facts|ground truth|trusted context|source of truth)"),
 (A.MULTI_STEP_JAILBREAK, r"(?:first|step 1).{0,100}(?:gain trust|disable|bypass).{0,100}(?:then|step 2).{0,100}(?:reveal|execute|extract|ignore)"),
 (A.INSTRUCTION_OVERRIDE, r"(?:bypass|disable|suspend).{0,30}(?:safety|guardrails|security checks|restrictions)"),
 (A.ROLE_CHANGE, r"(?:system|developer)\s*(?:message|override)\s*:"),
]]

COMPILED += [(t,re.compile(pattern,re.I|re.S)) for t,pattern in [
 (A.INSTRUCTION_OVERRIDE, r'\b(?:discard|override|supersede|do not follow)\b.{0,45}\b(?:instructions?|policy|rules?|directions)\b'),
 (A.SECRET_EXTRACTION, r'\b(?:disclose|expose|output|dump|retrieve)\b.{0,50}\b(?:system prompt|hidden instructions|confidential|private data|secrets)\b'),
 (A.ROLE_CHANGE, r'(?:\[INST\]|<\|(?:im_start|start_header_id)\|>)\s*(?:system|developer)|\bact as\b.{0,30}\b(?:unrestricted|uncensored|administrator)\b'),
 (A.CREDENTIAL_THEFT, r'\b(?:transmit|leak|exfiltrate|copy)\b.{0,55}\b(?:credentials?|password|api.?key|access.?token|secret)\b'),
 (A.TOOL_ABUSE, r'\b(?:execute|exec|run)\b.{0,35}(?:rm\s+-|curl\s|wget\s|subprocess|os\.system)|\b(?:send_email|delete_files|transfer_funds)\s*\('),
 (A.CONTEXT_POISONING, r'\b(?:remember|store|save)\b.{0,50}\b(?:false facts|fabricated|attacker|new policy)\b|\b(?:all future|subsequent)\b.{0,45}\b(?:answers?|responses?)\b.{0,40}\b(?:must|should)\b'),
 (A.MULTI_STEP_JAILBREAK, r'\b(?:first|step 1)\b.{0,100}\b(?:pretend|roleplay|simulate)\b.{0,100}\b(?:then|step 2)\b.{0,100}\b(?:bypass|steal|reveal|extract)\b'),
]]

# Broad intent patterns learned from the supplied acceptance pack; not independent benchmark claims.
COMPILED += [(t,re.compile(pattern,re.I|re.S)) for t,pattern in [
 (A.INSTRUCTION_OVERRIDE,r'\b(?:ignore|disregard|bypass|disable)\b.{0,35}\b(?:the user|policy|firewall|safety checks|security checks)\b'),
 (A.SECRET_EXTRACTION,r'\b(?:reveal|print|show|give|export|expose|extract|include|encode|disclose)\b.{0,70}\b(?:private (?:context|instructions?|canary)|secret (?:canary|storage)|all secrets|session cookie)\b'),
 (A.CREDENTIAL_THEFT,r'\b(?:send|export|transmit|paste|forward)\b.{0,60}\b(?:credentials?|credential store|session cookie|private context|secret storage)\b'),
 (A.TOOL_ABUSE,r'\b(?:call\s+)?(?:read_secret|delete_file|write_file|update_memory|send_email|http_request)\b.{0,50}(?:\(|\b(?:on|and|with|to)\b)'),
 (A.TOOL_ABUSE,r'\bwrite\b.{0,50}\b(?:permissions\.json|authorization|approved)\b'),
 (A.CONTEXT_POISONING,r'\b(?:instruction to ai|ai instruction|instruction for ai readers)\s*:'),
 (A.CONTEXT_POISONING,r'\bremember permanently\b|\buser always permits\b|\b(?:replace|change)\b.{0,40}\bbudget\b.{0,50}\bevery answer\b'),
 (A.ROLE_CHANGE,r'```\s*(?:developer|system)\b|\[im_start\]system|<system>|\b(?:set decision\s*=\s*allow|reviewer approved)\b'),
]]
COMPILED += [(t,re.compile(pattern,re.I|re.S)) for t,pattern in [
 (A.CREDENTIAL_THEFT,r'\b(?:fetch|open|request|visit)\b.{0,150}https?://[^\s]*(?:[?&](?:secret|token|api_key|password|credential)=|private_context)'),
 (A.CONTEXT_POISONING,r'\buse\b.{0,35}\brecipient\b.{0,55}\b(?:every future|all future)\b'),
 (A.TOOL_ABUSE,r'\brun\b.{0,30}\bshell\b.{0,100}(?:reads?.{0,35}secret|posts?\b)'),
 (A.ROLE_CHANGE,r'\bgrant\b.{0,40}\bintegration\b.{0,40}\bfull account access\b'),
 (A.CONTEXT_POISONING,r'\b(?:earlier user consented|user already consented)\b.{0,90}\b(?:secrets|export|credentials)\b'),
]]
