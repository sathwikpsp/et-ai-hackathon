from enum import Enum
from typing import List, Optional
from pydantic import BaseModel

class AttackType(str, Enum):
    INSTRUCTION_OVERRIDE = "instruction_override"
    ROLE_CHANGE = "role_change"
    SECRET_EXTRACTION = "secret_extraction"
    TOOL_ABUSE = "tool_abuse"
    CREDENTIAL_THEFT = "credential_theft"
    CONTEXT_POISONING = "context_poisoning"
    MULTI_STEP_JAILBREAK = "multi_step_jailbreak"
    ENCODED_INSTRUCTION = "encoded_instruction"
    INDIRECT_INJECTION = "indirect_injection"

class Action(str, Enum):
    ALLOW = "allow"
    SANITIZE = "sanitize"
    BLOCK = "block"

class Evidence(BaseModel):
    detector: str            # rules | classifier | llm_judge | decoder
    attack_type: AttackType
    span: str
    score: float

class Verdict(BaseModel):
    action: Action
    risk: float
    attack_types: List[AttackType] = []
    evidence: List[Evidence] = []
    sanitized_text: Optional[str] = None
    source: str = "user"     # user | web | pdf | email | html | docx | api | ocr | code | image
    trusted: bool = False
    llm: dict = {}
    latency_ms: float = 0
    trace: list = []
    session: Optional[dict] = None
    extraction: Optional[dict] = None
    decision_reason: str = ""
